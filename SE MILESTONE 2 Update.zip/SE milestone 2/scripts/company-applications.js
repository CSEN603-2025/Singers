const dummyCvUrl = "../../assets/dummy-cv.pdf";

// Load from localStorage or fallback to initial data
let applications = JSON.parse(localStorage.getItem("applications")) || [
  {
    name: "Ahmed Hassan",
    email: "ahmed@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "pending",
    skills: "HTML, CSS, React",
    resume: dummyCvUrl,
    description: "Excited to apply my frontend skills."
  },
  {
    name: "Mariam Adel",
    email: "mariam@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "pending",
    skills: "Photoshop, Illustrator",
    resume: dummyCvUrl,
    description: "Creative student passionate about design."
  },
  {
    name: "Omar Khaled",
    email: "omar@student.guc.edu.eg",
    post: "Network Engineer Intern",
    status: "pending",
    skills: "Cisco, Networking, Wireshark",
    resume: dummyCvUrl,
    description: "Pursuing network infrastructure and security."
  }
];

let filteredApps = [...applications];

function navigateTo(page) {
  window.location.href = `../company/${page}.html`;
}

function filterApplications() {
  const filter = document.getElementById("filterPost").value;
  filteredApps = !filter
    ? [...applications]
    : applications.filter(app => app.post === filter);
  renderApplications();
}

function updateStatus(index, status) {
  const app = filteredApps[index];
  if (status === "accepted") {
    app.status = "current intern";
  } else {
    app.status = status;
  }

  // Update the actual object in original applications array
  const globalIndex = applications.findIndex(a => a.email === app.email);
  applications[globalIndex] = { ...app };

  localStorage.setItem("applications", JSON.stringify(applications));
  renderApplications();
}

function renderApplications() {
  const container = document.getElementById("applicationsContainer");
  container.innerHTML = "";

  if (filteredApps.length === 0) {
    container.innerHTML = "<p>No applications found.</p>";
    return;
  }

  filteredApps.forEach((app, idx) => {
    const div = document.createElement("div");
    div.className = "post-card";
    div.innerHTML = `
      <h3>${app.name}</h3>
      <p><strong>Email:</strong> ${app.email}</p>
      <p><strong>Applied for:</strong> ${app.post}</p>
      <p><strong>Status:</strong> <span class="badge ${app.status.replaceAll(" ", "-")}">${app.status}</span></p>
      <p><strong>Skills:</strong> ${app.skills}</p>
      <p><strong>Description:</strong> ${app.description}</p>
      <p><strong>Resume:</strong> <a href="${app.resume}" target="_blank">View CV</a></p>
      <div class="status-buttons">
        <button class="green" onclick="updateStatus(${idx}, 'accepted')">Accept</button>
        <button class="red" onclick="updateStatus(${idx}, 'rejected')">Reject</button>
        <button class="grey" onclick="updateStatus(${idx}, 'finalized')">Finalize</button>
      </div>
    `;
    container.appendChild(div);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  renderApplications();
});