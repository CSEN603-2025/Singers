let posts = JSON.parse(localStorage.getItem("posts")) || [
  {
    title: "Frontend Developer Intern",
    industry: "Software",
    location: "Cairo",
    duration: "3 months",
    salary: "3000 EGP",
    paid: true,
    skills: "HTML, CSS, JS",
    description: "Assist in building UIs.",
    company: "TechNova"
  }
];

function navigateTo(page) {
  window.location.href = `../company/${page}.html`;
}

function toggleAddForm() {
  document.getElementById("addForm").classList.toggle("hidden");
}

function toggleFilter() {
  document.getElementById("filterForm").classList.toggle("hidden");
}

function addPost(e) {
  e.preventDefault();
  const post = {
    title: document.getElementById("title").value,
    industry: document.getElementById("industry").value,
    location: document.getElementById("location").value,
    duration: document.getElementById("duration").value,
    salary: document.getElementById("salary").value,
    paid: document.getElementById("paid").value === "true",
    skills: document.getElementById("skills").value,
    description: document.getElementById("description").value,
    company: "TechNova"
  };
  posts.unshift(post);
localStorage.setItem("posts", JSON.stringify(posts));
renderPosts(posts);
  document.getElementById("addForm").reset();
  toggleAddForm();
}

function filterPosts(e) {
  e.preventDefault();
  const industry = document.getElementById("filterIndustry").value;
  const duration = document.getElementById("filterDuration").value;
  const paid = document.getElementById("filterPaid").value;

  const filtered = posts.filter(p =>
    (industry === "" || p.industry === industry) &&
    (duration === "" || p.duration === duration) &&
    (paid === "" || String(p.paid) === paid)
  );

  renderPosts(filtered);
}

function renderPosts(data) {
  const container = document.getElementById("postsContainer");
  container.innerHTML = "";

  if (data.length === 0) {
    container.innerHTML = "<p>No internships available.</p>";
    return;
  }

  data.forEach(p => {
    const div = document.createElement("div");
    div.className = "post-card";
    div.innerHTML = `
      <h3>${p.title}</h3>
      <p><strong>Company:</strong> ${p.company}</p>
      <p><strong>Industry:</strong> ${p.industry}</p>
      <p><strong>Location:</strong> ${p.location}</p>
      <p><strong>Duration:</strong> ${p.duration}</p>
      <p><strong>Paid:</strong> ${p.paid ? "Yes" : "No"} ${p.paid ? `(${p.salary})` : ""}</p>
      <p><strong>Skills:</strong> ${p.skills}</p>
      <p><strong>Description:</strong> ${p.description}</p>
    `;
    container.appendChild(div);
  });
}
function toggleNotifications() {
  const panel = document.getElementById("notifPanel");
  panel.classList.toggle("hidden");

  document.getElementById("notifCount").classList.add("hidden");
  localStorage.setItem("notificationsRead", "true");
}

function loadNotifications() {
  const list = document.getElementById("notifList");
  const notifs = JSON.parse(localStorage.getItem("notifications")) || [];

 list.innerHTML = "";
notifs.slice().reverse().forEach((n, i) => {
  const li = document.createElement("li");
  li.innerText = n.message;
  li.classList.add("clickable-notif");
  li.onclick = () => handleNotificationClick(n.message);
  list.appendChild(li);
});
function handleNotificationClick(message) {
  document.getElementById("notifModalMessage").innerText = message;
  document.getElementById("notifModal").classList.remove("hidden");
}
function closeNotifModal() {
  document.getElementById("notifModal").classList.add("hidden");
}


  const unread = localStorage.getItem("notificationsRead") !== "true";
  if (notifs.length > 0 && unread) {
    const badge = document.getElementById("notifCount");
    badge.innerText = notifs.length;
    badge.classList.remove("hidden");
  }
}

function addNotification(message) {
  const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
  notifs.push({ message, timestamp: Date.now() });
  localStorage.setItem("notifications", JSON.stringify(notifs));
  localStorage.setItem("notificationsRead", "false");
  loadNotifications();
}

// Dummy data to start
posts = [
  {
    title: "Frontend Developer Intern",
    industry: "Software",
    location: "Cairo",
    duration: "3 months",
    salary: "3000 EGP",
    paid: true,
    skills: "HTML, CSS, JS",
    description: "Assist in building UIs.",
    company: "TechNova"
  },
  {
    title: "Graphic Design Intern",
    industry: "Design",
    location: "Remote",
    duration: "2 months",
    salary: "Unpaid",
    paid: false,
    skills: "Adobe Photoshop, Illustrator, Figma",
    description: "Support the design team in creating social media visuals, infographics, and mockups.",
    company: "TechNova"
  },
  {
    title: "Social Media Intern",
    industry: "Marketing",
    location: "Cairo",
    duration: "1 month",
    salary: "1000 EGP",
    paid: true,
    skills: "Instagram, Facebook, Copywriting",
    description: "Manage daily posts and engagement for TechNova's digital platforms.",
    company: "TechNova"
  },
  {
    title: "Quality Assurance Intern",
    industry: "Software Testing",
    location: "Giza",
    duration: "3 months",
    salary: "2500 EGP",
    paid: true,
    skills: "Manual Testing, TestRail, Jira",
    description: "Test features, log bugs, and collaborate with developers to ensure a high-quality product.",
    company: "TechNova"
  },
  {
    title: "Content Writer Intern",
    industry: "Media",
    location: "Remote",
    duration: "1 month",
    salary: "Unpaid",
    paid: false,
    skills: "English Writing, SEO, WordPress",
    description: "Create and edit blog articles and landing page content to support marketing goals.",
    company: "TechNova"
  },
  {
    title: "Network Engineer Intern",
    industry: "IT",
    location: "Cairo",
    duration: "3 months",
    salary: "3500 EGP",
    paid: true,
    skills: "Cisco, Networking, Wireshark",
    description: "Assist with infrastructure maintenance and resolve connectivity issues across offices.",
    company: "TechNova"
  },
  {
    title: "Project Coordinator Intern",
    industry: "Business",
    location: "Hybrid",
    duration: "2 months",
    salary: "1500 EGP",
    paid: true,
    skills: "Planning, Communication, Excel",
    description: "Help coordinate tasks, schedules, and reporting with project stakeholders.",
    company: "TechNova"
  }
];
addNotification("📥 A student applied to your internship!");
addNotification("✅ SCAD has approved your company.");
document.addEventListener("DOMContentLoaded", () => renderPosts(posts));