// Load from localStorage or initialize with dummy data
let interns = JSON.parse(localStorage.getItem("interns")) || [
  {
    name: "Laila Mansour",
    email: "laila@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "current intern",
    skills: "Adobe XD, Illustrator, Creativity",
    resume: "../../assets/dummy-cv.pdf",
    description: "Looking forward to contributing to TechNova's branding."
  },
  {
    name: "Youssef Hatem",
    email: "youssef@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "internship complete",
    skills: "React, JavaScript, HTML",
    resume: "../../assets/dummy-cv.pdf",
    description: "Loved working on the UI for internal dashboards.",
  },
  {
    name: "Sara Helmy",
    email: "sara@student.guc.edu.eg",
    post: "Marketing Intern",
    status: "internship complete",
    skills: "SEO, Social Media, Google Analytics",
    resume: "../../assets/dummy-cv.pdf",
    description: "Helped boost engagement by 20% through targeted posts.",
  },
  {
    name: "Omar Fathy",
    email: "omar@student.guc.edu.eg",
    post: "Backend Developer Intern",
    status: "current intern",
    skills: "Node.js, MongoDB, Express",
    resume: "../../assets/dummy-cv.pdf",
    description: "Eager to apply backend development skills in a real project."
  }
];

let filtered = [...interns];


function navigateTo(page) {
  window.location.href = `../company/${page}.html`;
}

function filterInterns() {
  const query = document.getElementById("searchName").value.toLowerCase();
  const status = document.getElementById("statusFilter").value;

  filtered = interns.filter(intern =>
    (status === "" || intern.status === status) &&
    (intern.name.toLowerCase().includes(query) || intern.post.toLowerCase().includes(query))
  );

  renderInterns();
}

function viewProfile(cvUrl) {
  window.open(cvUrl, "_blank");
}


let currentEvalIndex = null;

function evaluateIntern(index) {
  currentEvalIndex = index;
  document.getElementById("evaluationText").value = filtered[index].evaluation || "";
  document.getElementById("evaluationModal").classList.remove("hidden");
}

function closeEvaluationModal() {
  document.getElementById("evaluationModal").classList.add("hidden");
  currentEvalIndex = null;
}

function submitEvaluation() {
  const text = document.getElementById("evaluationText").value.trim();
  if (!text) return alert("Please write an evaluation first.");

  // Save to filtered and main list
  filtered[currentEvalIndex].evaluation = text;

  const originalIndex = interns.findIndex(i => i.email === filtered[currentEvalIndex].email);
  interns[originalIndex] = { ...filtered[currentEvalIndex] };

  localStorage.setItem("interns", JSON.stringify(interns));

  closeEvaluationModal();
  renderInterns();
}


function renderInterns() {
  const container = document.getElementById("internsContainer");
  container.innerHTML = "";

  if (filtered.length === 0) {
    container.innerHTML = "<p>No interns found.</p>";
    return;
  }

  filtered.forEach((intern, i) => {
    const div = document.createElement("div");
    div.className = "post-card";
    div.innerHTML = `
      <h3>${intern.name}</h3>
      <p><strong>Job Title:</strong> ${intern.post}</p>
      <p><strong>Status:</strong> <span class="badge ${intern.status.replaceAll(" ", "-")}">${intern.status}</span></p>
      <p><strong>Email:</strong> ${intern.email}</p>
      <p><strong>Skills:</strong> ${intern.skills}</p>
      <div class="status-buttons">
        <button class="grey" onclick="viewProfile('${intern.resume}')">View Profile</button>
        ${intern.status === "internship complete"
          ? `<button class="green" onclick="evaluateIntern(${i})">Evaluate</button>` : ""}
      </div>
      ${intern.evaluation ? `<p><strong>Evaluation:</strong> ${intern.evaluation}</p>` : ""}
    `;
    container.appendChild(div);
  });
}

document.addEventListener("DOMContentLoaded", renderInterns);