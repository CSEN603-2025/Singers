// Dummy reports data with realistic information
const reports = [
    {
        id: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-12345",
        major: "cs",
        title: "February Progress Report",
        submissionDate: "2024-03-01",
        company: "TechCorp Solutions",
        supervisor: "John Smith",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "pending",
        content: {
            technicalSkills: ["React", "Node.js", "MongoDB"],
            projectDescription: "Developing a customer management system",
            learningOutcomes: "Improved full-stack development skills",
            challenges: "Integration with legacy systems"
        }
    },
    {
        id: 2,
        studentName: "Sarah Ahmed",
        studentId: "49-12346",
        major: "iet",
        title: "Final Internship Report",
        submissionDate: "2024-03-15",
        company: "FinanceHub",
        supervisor: "Mary Johnson",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        status: "flagged",
        content: {
            technicalSkills: ["Python", "Data Analysis", "SQL"],
            projectDescription: "Financial data visualization platform",
            learningOutcomes: "Enhanced data analysis capabilities",
            challenges: "Complex data processing requirements"
        }
    },
    {
        id: 3,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        major: "dmet",
        title: "Mid-term Evaluation",
        submissionDate: "2024-02-15",
        company: "HealthCare Plus",
        supervisor: "David Wilson",
        startDate: "2024-01-01",
        endDate: "2024-07-01",
        status: "accepted",
        content: {
            technicalSkills: ["UI/UX Design", "Adobe XD", "Flutter"],
            projectDescription: "Mobile healthcare application design",
            learningOutcomes: "Mastered mobile-first design principles",
            challenges: "Accessibility compliance"
        }
    }
];

// Statistics data
const statistics = {
    currentCycle: {
        total: 30,
        accepted: 15,
        rejected: 5,
        flagged: 4,
        pending: 6
    },
    byMajor: {
        cs: 12,
        iet: 10,
        dmet: 8
    },
    averageReviewTime: "2.5 days",
    topCompanies: [
        { name: "TechCorp Solutions", count: 8, rating: 4.8 },
        { name: "FinanceHub", count: 6, rating: 4.6 },
        { name: "CloudTech Solutions", count: 5, rating: 4.7 }
    ]
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initial render of reports
    renderReports(reports);

    // Setup search and filter functionality
    setupFilters();

    // Setup modal close functionality
    setupModals();
});

function renderReports(reportsList) {
    const reportsGrid = document.getElementById('reportsGrid');
    reportsGrid.innerHTML = reportsList.map(report => `
        <div class="report-item" onclick="showReportDetails(${report.id})">
            <div class="report-info">
                <div class="report-title">
                    <h3>${report.title}</h3>
                    <span class="report-status status-${report.status}">
                        ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                    </span>
                </div>
                <div class="report-meta">
                    <p><strong>Student:</strong> ${report.studentName} (${report.studentId})</p>
                    <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
                    <p><strong>Company:</strong> ${report.company}</p>
                    <p><strong>Submitted:</strong> ${report.submissionDate}</p>
                </div>
            </div>
        </div>
    `).join('');
}

function setupFilters() {
    const searchInput = document.getElementById('searchReport');
    const majorFilter = document.getElementById('majorFilter');
    const statusFilter = document.getElementById('reportStatusFilter');

    const filterReports = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedMajor = majorFilter.value;
        const selectedStatus = statusFilter.value;

        const filteredReports = reports.filter(report => {
            const matchesSearch = 
                report.studentName.toLowerCase().includes(searchTerm) ||
                report.studentId.toLowerCase().includes(searchTerm) ||
                report.company.toLowerCase().includes(searchTerm);
            const matchesMajor = !selectedMajor || report.major === selectedMajor;
            const matchesStatus = !selectedStatus || report.status === selectedStatus;
            
            return matchesSearch && matchesMajor && matchesStatus;
        });

        renderReports(filteredReports);
    };

    searchInput.addEventListener('input', filterReports);
    majorFilter.addEventListener('change', filterReports);
    statusFilter.addEventListener('change', filterReports);
}

function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.close-modal');

    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            modals.forEach(modal => modal.style.display = 'none');
        });
    });

    window.addEventListener('click', (e) => {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

function updateReportStatus(reportId, newStatus, reason = '') {
    const reportIndex = reports.findIndex(r => r.id === reportId);
    if (reportIndex === -1) return;

    reports[reportIndex] = {
        ...reports[reportIndex],
        status: newStatus,
        statusReason: reason,
        statusUpdatedAt: new Date().toISOString()
    };

    // Re-render the reports grid
    renderReports(reports);
    
    // Update the modal if it's open
    const modal = document.getElementById('reportModal');
    if (modal.style.display === 'block') {
        showReportDetails(reportId);
    }
}

function approveReport() {
    const reportId = parseInt(document.getElementById('modalReportTitle').dataset.reportId);
    updateReportStatus(reportId, 'accepted');
    alert('Report has been approved successfully!');
}

function rejectReport() {
    const reportId = parseInt(document.getElementById('modalReportTitle').dataset.reportId);
    
    // Create and show the rejection modal
    const rejectModal = document.createElement('div');
    rejectModal.className = 'modal';
    rejectModal.innerHTML = `
        <div class="modal-content">
            <h3>Reject Report</h3>
            <textarea id="rejectionReason" placeholder="Please provide a reason for rejection..." rows="4" style="width: 100%; margin: 10px 0;"></textarea>
            <div class="action-buttons">
                <button class="btn btn-reject" onclick="submitRejection(${reportId})">Submit Rejection</button>
                <button class="btn" onclick="this.parentElement.parentElement.parentElement.remove()">Cancel</button>
            </div>
        </div>
    `;
    document.body.appendChild(rejectModal);
    rejectModal.style.display = 'block';
}

function submitRejection(reportId) {
    const reason = document.getElementById('rejectionReason').value.trim();
    if (!reason) {
        alert('Please provide a reason for rejection.');
        return;
    }
    
    updateReportStatus(reportId, 'rejected', reason);
    alert('Report has been rejected successfully!');
    document.querySelector('.modal:last-child').remove();
}

function flagReport() {
    const reportId = parseInt(document.getElementById('modalReportTitle').dataset.reportId);
    
    // Create and show the flag modal
    const flagModal = document.createElement('div');
    flagModal.className = 'modal';
    flagModal.innerHTML = `
        <div class="modal-content">
            <h3>Flag Report for Review</h3>
            <textarea id="flagReason" placeholder="Please provide a reason for flagging..." rows="4" style="width: 100%; margin: 10px 0;"></textarea>
            <div class="action-buttons">
                <button class="btn" onclick="submitFlag(${reportId})">Submit Flag</button>
                <button class="btn" onclick="this.parentElement.parentElement.parentElement.remove()">Cancel</button>
            </div>
        </div>
    `;
    document.body.appendChild(flagModal);
    flagModal.style.display = 'block';
}

function submitFlag(reportId) {
    const reason = document.getElementById('flagReason').value.trim();
    if (!reason) {
        alert('Please provide a reason for flagging.');
        return;
    }
    
    updateReportStatus(reportId, 'flagged', reason);
    alert('Report has been flagged for review!');
    document.querySelector('.modal:last-child').remove();
}

function showReportDetails(reportId) {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    const modal = document.getElementById('reportModal');
    const modalReportTitle = document.getElementById('modalReportTitle');
    const modalReportDetails = document.getElementById('modalReportDetails');

    modalReportTitle.textContent = report.title;
    modalReportTitle.dataset.reportId = reportId;  // Store the report ID for later use

    let statusInfo = `
        <div class="status-badge status-${report.status}">
            ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
        </div>`;
    
    if (report.statusReason && (report.status === 'rejected' || report.status === 'flagged')) {
        statusInfo += `
            <div class="status-reason">
                <strong>Reason:</strong> ${report.statusReason}
            </div>`;
    }

    modalReportDetails.innerHTML = `
        <div class="report-details">
            <div class="report-header">
                ${statusInfo}
                <div class="report-info">
                    <p><strong>Student Name:</strong> ${report.studentName}</p>
                    <p><strong>Student ID:</strong> ${report.studentId}</p>
                    <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
                    <p><strong>Company:</strong> ${report.company}</p>
                    <p><strong>Supervisor:</strong> ${report.supervisor}</p>
                    <p><strong>Internship Period:</strong> ${report.startDate} to ${report.endDate}</p>
                    <p><strong>Submission Date:</strong> ${report.submissionDate}</p>
                </div>
            </div>
            <div class="report-content">
                <h4>Technical Skills</h4>
                <p>${report.content.technicalSkills.join(', ')}</p>
                
                <h4>Project Description</h4>
                <p>${report.content.projectDescription}</p>
                
                <h4>Learning Outcomes</h4>
                <p>${report.content.learningOutcomes}</p>
                
                <h4>Challenges</h4>
                <p>${report.content.challenges}</p>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function viewStatistics() {
    const modal = document.getElementById('statisticsModal');
    const statisticsContent = document.getElementById('statisticsContent');

    statisticsContent.innerHTML = `
        <div class="statistics-grid">
            <div class="stat-card">
                <h3>Current Cycle Overview</h3>
                <div class="stat-content">
                    <p>Total Reports: ${statistics.currentCycle.total}</p>
                    <p>Accepted: ${statistics.currentCycle.accepted}</p>
                    <p>Rejected: ${statistics.currentCycle.rejected}</p>
                    <p>Flagged: ${statistics.currentCycle.flagged}</p>
                    <p>Pending: ${statistics.currentCycle.pending}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Distribution by Major</h3>
                <div class="stat-content">
                    <p>Computer Science: ${statistics.byMajor.cs}</p>
                    <p>IET: ${statistics.byMajor.iet}</p>
                    <p>DMET: ${statistics.byMajor.dmet}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Performance Metrics</h3>
                <div class="stat-content">
                    <p>Average Review Time: ${statistics.averageReviewTime}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Top Companies</h3>
                <div class="stat-content">
                    ${statistics.topCompanies.map(company => `
                        <div class="company-stat">
                            <p>${company.name}</p>
                            <p>Interns: ${company.count}</p>
                            <p>Rating: ${company.rating}/5.0</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function generateReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Add title
    doc.setFontSize(18);
    doc.text('Faculty Internship Reports Summary', 20, 20);

    // Add current date
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);

    // Add statistics
    doc.setFontSize(14);
    doc.text('Current Cycle Statistics', 20, 45);
    doc.setFontSize(12);
    doc.text(`Total Reports: ${statistics.currentCycle.total}`, 30, 55);
    doc.text(`Accepted: ${statistics.currentCycle.accepted}`, 30, 62);
    doc.text(`Rejected: ${statistics.currentCycle.rejected}`, 30, 69);
    doc.text(`Flagged: ${statistics.currentCycle.flagged}`, 30, 76);
    doc.text(`Pending: ${statistics.currentCycle.pending}`, 30, 83);

    // Add reports table
    const tableData = reports.map(report => [
        report.studentName,
        report.studentId,
        report.major.toUpperCase(),
        report.company,
        report.submissionDate,
        report.status.charAt(0).toUpperCase() + report.status.slice(1)
    ]);

    doc.autoTable({
        startY: 95,
        head: [['Student Name', 'ID', 'Major', 'Company', 'Submission Date', 'Status']],
        body: tableData,
        theme: 'grid',
        styles: { fontSize: 10 },
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Save the PDF
    doc.save('faculty-internship-reports.pdf');
}

function submitClarification() {
    const clarification = prompt('Please enter your clarification:');
    if (clarification) {
        alert('Clarification submitted successfully!');
        // Here you would typically send the clarification to your backend
    }
}
