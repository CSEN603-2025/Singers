// Dummy reports data with realistic information
const reports = [
    {
        id: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-12345",
        major: "cs",
        title: "February Progress Report",
        submissionDate: "2024-03-01",
        company: "TechCorp Solutions",
        supervisor: "John Smith",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "pending",
        content: {
            technicalSkills: ["React", "Node.js", "MongoDB"],
            projectDescription: "Developing a customer management system",
            learningOutcomes: "Improved full-stack development skills",
            challenges: "Integration with legacy systems"
        }
    },
    {
        id: 2,
        studentName: "Sarah Ahmed",
        studentId: "49-12346",
        major: "iet",
        title: "Final Internship Report",
        submissionDate: "2024-03-15",
        company: "FinanceHub",
        supervisor: "Mary Johnson",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        status: "flagged",
        content: {
            technicalSkills: ["Python", "Data Analysis", "SQL"],
            projectDescription: "Financial data visualization platform",
            learningOutcomes: "Enhanced data analysis capabilities",
            challenges: "Complex data processing requirements"
        }
    },
    {
        id: 3,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        major: "dmet",
        title: "Mid-term Evaluation",
        submissionDate: "2024-02-15",
        company: "HealthCare Plus",
        supervisor: "David Wilson",
        startDate: "2024-01-01",
        endDate: "2024-07-01",
        status: "accepted",
        content: {
            technicalSkills: ["UI/UX Design", "Adobe XD", "Flutter"],
            projectDescription: "Mobile healthcare application design",
            learningOutcomes: "Mastered mobile-first design principles",
            challenges: "Accessibility compliance"
        }
    },
    {
        id: 4,
        studentName: "Nour Ibrahim",
        studentId: "49-12348",
        major: "cs",
        title: "Monthly Progress Report",
        submissionDate: "2024-03-10",
        company: "CloudTech Solutions",
        supervisor: "Emily Brown",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "rejected",
        content: {
            technicalSkills: ["AWS", "Docker", "Kubernetes"],
            projectDescription: "Cloud infrastructure automation",
            learningOutcomes: "Cloud architecture expertise",
            challenges: "System scalability issues"
        }
    },
    {
        id: 5,
        studentName: "Youssef Ali",
        studentId: "49-12349",
        major: "iet",
        title: "Final Report",
        submissionDate: "2024-03-05",
        company: "SmartSystems Inc",
        supervisor: "Michael Chen",
        startDate: "2023-09-15",
        endDate: "2024-03-15",
        status: "accepted",
        content: {
            technicalSkills: ["IoT", "Embedded Systems", "C++"],
            projectDescription: "Smart home automation system",
            learningOutcomes: "Hardware-software integration",
            challenges: "Power consumption optimization"
        }
    }
];

// Statistics data
const statistics = {
    currentCycle: {
        total: 50,
        accepted: 25,
        rejected: 8,
        flagged: 7,
        pending: 10
    },
    byMajor: {
        cs: 20,
        iet: 15,
        dmet: 15
    },
    averageReviewTime: "3.5 days",
    topCompanies: [
        { name: "TechCorp Solutions", count: 12, rating: 4.8 },
        { name: "FinanceHub", count: 8, rating: 4.6 },
        { name: "CloudTech Solutions", count: 7, rating: 4.7 }
    ]
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initial render of reports
    renderReports(reports);

    // Setup search and filter functionality
    setupFilters();

    // Setup modal close functionality
    setupModals();
});

function renderReports(reportsList) {
    const reportsGrid = document.getElementById('reportsGrid');
    reportsGrid.innerHTML = reportsList.map(report => `
        <div class="report-item" onclick="showReportDetails(${report.id})">
            <div class="report-info">
                <div class="report-title">
                    <h3>${report.title}</h3>
                    <span class="report-status status-${report.status}">
                        ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                    </span>
                </div>
                <div class="report-meta">
                    <p><strong>Student:</strong> ${report.studentName} (${report.studentId})</p>
                    <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
                    <p><strong>Company:</strong> ${report.company}</p>
                    <p><strong>Submitted:</strong> ${report.submissionDate}</p>
                </div>
            </div>
        </div>
    `).join('');
}

function setupFilters() {
    const searchInput = document.getElementById('searchReport');
    const majorFilter = document.getElementById('majorFilter');
    const statusFilter = document.getElementById('reportStatusFilter');

    const filterReports = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedMajor = majorFilter.value;
        const selectedStatus = statusFilter.value;

        const filteredReports = reports.filter(report => {
            const matchesSearch = 
                report.studentName.toLowerCase().includes(searchTerm) ||
                report.studentId.toLowerCase().includes(searchTerm) ||
                report.company.toLowerCase().includes(searchTerm);
            const matchesMajor = !selectedMajor || report.major === selectedMajor;
            const matchesStatus = !selectedStatus || report.status === selectedStatus;
            
            return matchesSearch && matchesMajor && matchesStatus;
        });

        renderReports(filteredReports);
    };

    searchInput.addEventListener('input', filterReports);
    majorFilter.addEventListener('change', filterReports);
    statusFilter.addEventListener('change', filterReports);
}

function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closeButtons = document.querySelectorAll('.close-modal');

    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            modals.forEach(modal => modal.style.display = 'none');
        });
    });

    window.addEventListener('click', (e) => {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

function showReportDetails(reportId) {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    const modal = document.getElementById('reportModal');
    const modalReportTitle = document.getElementById('modalReportTitle');
    const modalReportDetails = document.getElementById('modalReportDetails');

    modalReportTitle.textContent = report.title;
    modalReportDetails.innerHTML = `
        <div class="report-details">
            <div class="report-header">
                <div class="status-badge status-${report.status}">
                    ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                </div>
                <div class="report-info">
                    <p><strong>Student Name:</strong> ${report.studentName}</p>
                    <p><strong>Student ID:</strong> ${report.studentId}</p>
                    <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
                    <p><strong>Company:</strong> ${report.company}</p>
                    <p><strong>Supervisor:</strong> ${report.supervisor}</p>
                    <p><strong>Internship Period:</strong> ${report.startDate} to ${report.endDate}</p>
                    <p><strong>Submission Date:</strong> ${report.submissionDate}</p>
                </div>
            </div>
            <div class="report-content">
                <h4>Technical Skills</h4>
                <p>${report.content.technicalSkills.join(', ')}</p>
                
                <h4>Project Description</h4>
                <p>${report.content.projectDescription}</p>
                
                <h4>Learning Outcomes</h4>
                <p>${report.content.learningOutcomes}</p>
                
                <h4>Challenges</h4>
                <p>${report.content.challenges}</p>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function viewStatistics() {
    const modal = document.getElementById('statisticsModal');
    const statisticsContent = document.getElementById('statisticsContent');

    statisticsContent.innerHTML = `
        <div class="statistics-grid">
            <div class="stat-card">
                <h3>Current Cycle Overview</h3>
                <div class="stat-content">
                    <p>Total Reports: ${statistics.currentCycle.total}</p>
                    <p>Accepted: ${statistics.currentCycle.accepted}</p>
                    <p>Rejected: ${statistics.currentCycle.rejected}</p>
                    <p>Flagged: ${statistics.currentCycle.flagged}</p>
                    <p>Pending: ${statistics.currentCycle.pending}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Distribution by Major</h3>
                <div class="stat-content">
                    <p>Computer Science: ${statistics.byMajor.cs}</p>
                    <p>IET: ${statistics.byMajor.iet}</p>
                    <p>DMET: ${statistics.byMajor.dmet}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Performance Metrics</h3>
                <div class="stat-content">
                    <p>Average Review Time: ${statistics.averageReviewTime}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Top Companies</h3>
                <div class="stat-content">
                    ${statistics.topCompanies.map(company => `
                        <div class="company-stat">
                            <p>${company.name}</p>
                            <p>Interns: ${company.count}</p>
                            <p>Rating: ${company.rating}/5.0</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function generateReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Add title
    doc.setFontSize(18);
    doc.text('Internship Reports Summary', 20, 20);

    // Add current date
    doc.setFontSize(12);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 30);

    // Add statistics
    doc.setFontSize(14);
    doc.text('Current Cycle Statistics', 20, 45);
    doc.setFontSize(12);
    doc.text(`Total Reports: ${statistics.currentCycle.total}`, 30, 55);
    doc.text(`Accepted: ${statistics.currentCycle.accepted}`, 30, 62);
    doc.text(`Rejected: ${statistics.currentCycle.rejected}`, 30, 69);
    doc.text(`Flagged: ${statistics.currentCycle.flagged}`, 30, 76);
    doc.text(`Pending: ${statistics.currentCycle.pending}`, 30, 83);

    // Add reports table
    const tableData = reports.map(report => [
        report.studentName,
        report.studentId,
        report.major.toUpperCase(),
        report.company,
        report.submissionDate,
        report.status.charAt(0).toUpperCase() + report.status.slice(1)
    ]);

    doc.autoTable({
        startY: 95,
        head: [['Student Name', 'ID', 'Major', 'Company', 'Submission Date', 'Status']],
        body: tableData,
        theme: 'grid',
        styles: { fontSize: 10 },
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Save the PDF
    doc.save('internship-reports-summary.pdf');
}

function approveReport() {
    alert('Report approved successfully!');
    // Here you would typically update the report status in your backend
}

function rejectReport() {
    const reason = prompt('Please enter the reason for rejection:');
    if (reason) {
        alert('Report rejected successfully!');
        // Here you would typically update the report status in your backend
    }
}

function flagReport() {
    const reason = prompt('Please enter the reason for flagging this report:');
    if (reason) {
        alert('Report flagged for review!');
        // Here you would typically update the report status in your backend
    }
}

function submitClarification() {
    const clarification = prompt('Please enter your clarification:');
    if (clarification) {
        alert('Clarification submitted successfully!');
        // Here you would typically send the clarification to your backend
    }
} 