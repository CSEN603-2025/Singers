// Dummy company data
const companies = [
    {
        id: 1,
        name: "TechCorp Solutions",
        industry: "tech",
        status: "pending",
        description: "Leading software development company",
        employees: "500+",
        location: "Cairo, Egypt",
        applicationDate: "2024-03-15"
    },
    {
        id: 2,
        name: "FinanceHub",
        industry: "finance",
        status: "accepted",
        description: "Investment and banking services",
        employees: "1000+",
        location: "Alexandria, Egypt",
        applicationDate: "2024-03-10"
    },
    {
        id: 3,
        name: "HealthCare Plus",
        industry: "healthcare",
        status: "pending",
        description: "Modern healthcare solutions provider",
        employees: "300+",
        location: "Giza, Egypt",
        applicationDate: "2024-03-18"
    },
    {
        id: 4,
        name: "Industrial Manufacturing Co.",
        industry: "manufacturing",
        status: "rejected",
        description: "Industrial equipment manufacturer",
        employees: "750+",
        location: "Cairo, Egypt",
        applicationDate: "2024-03-05"
    }
];

// Dummy reports data
const reports = [
    {
        id: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-12345",
        major: "cs",
        title: "February Progress Report",
        submissionDate: "2024-03-01",
        company: "TechCorp Solutions",
        supervisor: "John Smith",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "pending",
        pdfUrl: "../../assets/reports/progress-report-feb.pdf"
    },
    {
        id: 2,
        studentName: "Sarah Ahmed",
        studentId: "49-12346",
        major: "iet",
        title: "Final Report",
        submissionDate: "2024-03-15",
        company: "FinanceHub",
        supervisor: "Mary Johnson",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        status: "flagged",
        pdfUrl: "../../assets/reports/final-report.pdf"
    },
    {
        id: 3,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        major: "dmet",
        title: "Mid-term Evaluation",
        submissionDate: "2024-02-15",
        company: "HealthCare Plus",
        supervisor: "David Wilson",
        startDate: "2024-01-01",
        endDate: "2024-07-01",
        status: "accepted",
        pdfUrl: "../../assets/reports/midterm-evaluation.pdf"
    }
];

// Statistics data
const statistics = {
    currentCycle: {
        accepted: 15,
        rejected: 5,
        flagged: 3,
        pending: 7
    },
    averageReviewTime: "3.5 days",
    topCourses: [
        { name: "CSEN704", count: 25 },
        { name: "DMET502", count: 18 },
        { name: "CSEN603", count: 15 }
    ],
    topCompanies: [
        { name: "TechCorp Solutions", rating: 4.8 },
        { name: "FinanceHub", rating: 4.6 },
        { name: "HealthCare Plus", rating: 4.5 }
    ],
    companiesByInternshipCount: [
        { name: "TechCorp Solutions", count: 12 },
        { name: "FinanceHub", count: 8 },
        { name: "HealthCare Plus", count: 6 }
    ]
};

document.addEventListener('DOMContentLoaded', function() {
    const companiesGrid = document.getElementById('companiesGrid');
    const searchInput = document.getElementById('searchCompany');
    const industryFilter = document.getElementById('industryFilter');
    const modal = document.getElementById('companyModal');
    const modalCompanyName = document.getElementById('modalCompanyName');
    const modalCompanyDetails = document.getElementById('modalCompanyDetails');
    const closeModal = document.querySelector('.close-modal');

    // Initial render
    renderCompanies(companies);

    // Search functionality
    searchInput.addEventListener('input', filterCompanies);
    industryFilter.addEventListener('change', filterCompanies);

    // Close modal
    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Handle accept/reject buttons
    document.querySelector('.accept-btn').addEventListener('click', () => {
        const companyId = modal.dataset.companyId;
        updateCompanyStatus(companyId, 'accepted');
        modal.style.display = 'none';
    });

    document.querySelector('.reject-btn').addEventListener('click', () => {
        const companyId = modal.dataset.companyId;
        updateCompanyStatus(companyId, 'rejected');
        modal.style.display = 'none';
    });

    // Initialize tabs first
    initializeTabs();

    // Initialize reports functionality
    const searchReport = document.getElementById('searchReport');
    const majorFilter = document.getElementById('majorFilter');
    const statusFilter = document.getElementById('statusFilter');
    const reportModal = document.getElementById('reportModal');
    const statisticsModal = document.getElementById('statisticsModal');
    const closeModals = document.querySelectorAll('.close-modal');

    // Initial render of reports
    renderReports(reports);

    // Search and filter functionality for reports
    if (searchReport) {
        searchReport.addEventListener('input', filterReports);
    }
    if (majorFilter) {
        majorFilter.addEventListener('change', filterReports);
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', filterReports);
    }

    // Close modal functionality
    closeModals.forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            reportModal.style.display = 'none';
            statisticsModal.style.display = 'none';
        });
    });
});

function renderCompanies(companiesList) {
    const companiesGrid = document.getElementById('companiesGrid');
    companiesGrid.innerHTML = companiesList.map(company => `
        <div class="company-card" onclick="showCompanyDetails(${company.id})">
            <h3>${company.name}</h3>
            <p>${company.description}</p>
            <p><strong>Industry:</strong> ${company.industry}</p>
            <p><strong>Location:</strong> ${company.location}</p>
            <span class="company-status status-${company.status}">
                ${company.status.charAt(0).toUpperCase() + company.status.slice(1)}
            </span>
        </div>
    `).join('');
}

function filterCompanies() {
    const searchTerm = searchCompany.value.toLowerCase();
    const selectedIndustry = industryFilter.value;

    const filteredCompanies = companies.filter(company => {
        const matchesSearch = company.name.toLowerCase().includes(searchTerm) ||
                            company.description.toLowerCase().includes(searchTerm);
        const matchesIndustry = !selectedIndustry || company.industry === selectedIndustry;
        return matchesSearch && matchesIndustry;
    });

    renderCompanies(filteredCompanies);
}

function showCompanyDetails(companyId) {
    const company = companies.find(c => c.id === companyId);
    if (!company) return;

    const modal = document.getElementById('companyModal');
    const modalCompanyName = document.getElementById('modalCompanyName');
    const modalCompanyDetails = document.getElementById('modalCompanyDetails');

    modalCompanyName.textContent = company.name;
    modalCompanyDetails.innerHTML = `
        <p><strong>Industry:</strong> ${company.industry}</p>
        <p><strong>Description:</strong> ${company.description}</p>
        <p><strong>Employees:</strong> ${company.employees}</p>
        <p><strong>Location:</strong> ${company.location}</p>
        <p><strong>Application Date:</strong> ${company.applicationDate}</p>
        <p><strong>Status:</strong> <span class="company-status status-${company.status}">
            ${company.status.charAt(0).toUpperCase() + company.status.slice(1)}
        </span></p>
    `;

    modal.dataset.companyId = companyId;
    modal.style.display = 'block';
}

function updateCompanyStatus(companyId, newStatus) {
    const company = companies.find(c => c.id === parseInt(companyId));
    if (company) {
        company.status = newStatus;
        renderCompanies(companies);
    }
}

function switchTab(tab) {
    sessionStorage.setItem('activeTab', tab);
    
    const tabs = document.querySelectorAll('.nav-tab');
    const companiesSection = document.getElementById('companiesSection');
    const reportsSection = document.getElementById('reportsSection');

    tabs.forEach(t => {
        if (t.dataset.tab === tab) {
            t.classList.add('active');
        } else {
            t.classList.remove('active');
        }
    });

    // Show/hide sections based on active tab
    if (tab === 'companies') {
        companiesSection.style.display = 'block';
        reportsSection.style.display = 'none';
        if (!window.location.pathname.includes('scad-dashboard.html')) {
            window.location.href = '../scad-dashboard.html';
        }
    } else if (tab === 'students') {
        if (!window.location.pathname.includes('student-management.html')) {
            window.location.href = 'scad/student-management.html';
        }
    } else if (tab === 'reports') {
        companiesSection.style.display = 'none';
        reportsSection.style.display = 'block';
    }
}

// Initialize tabs when DOM is loaded
function initializeTabs() {
    const currentPath = window.location.pathname;
    const activeTab = currentPath.includes('student-management.html') ? 'students' : 'companies';
    sessionStorage.setItem('activeTab', activeTab);
    
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
        if ((activeTab === 'companies' && tab.textContent === 'Companies') ||
            (activeTab === 'students' && tab.textContent === 'Students')) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
}

function renderReports(reportsList) {
    const reportsGrid = document.getElementById('reportsGrid');
    if (!reportsGrid) return;

    reportsGrid.innerHTML = reportsList.map(report => `
        <div class="report-card" onclick="showReportDetails(${report.id})">
            <h3>${report.title}</h3>
            <p><strong>Student:</strong> ${report.studentName} (${report.studentId})</p>
            <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
            <p><strong>Company:</strong> ${report.company}</p>
            <p><strong>Submitted:</strong> ${report.submissionDate}</p>
            <span class="status-badge status-${report.status}">
                ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
            </span>
        </div>
    `).join('');
}

function filterReports() {
    const searchTerm = searchReport.value.toLowerCase();
    const selectedMajor = majorFilter.value;
    const selectedStatus = statusFilter.value;

    const filteredReports = reports.filter(report => {
        const matchesSearch = report.studentName.toLowerCase().includes(searchTerm) ||
                            report.studentId.toLowerCase().includes(searchTerm) ||
                            report.company.toLowerCase().includes(searchTerm);
        const matchesMajor = !selectedMajor || report.major === selectedMajor;
        const matchesStatus = !selectedStatus || report.status === selectedStatus;
        return matchesSearch && matchesMajor && matchesStatus;
    });

    renderReports(filteredReports);
}

function showReportDetails(reportId) {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    const modal = document.getElementById('reportModal');
    const modalReportTitle = document.getElementById('modalReportTitle');
    const modalReportDetails = document.getElementById('modalReportDetails');

    modalReportTitle.textContent = report.title;
    modalReportDetails.innerHTML = `
        <div class="report-details">
            <p><strong>Student Name:</strong> ${report.studentName}</p>
            <p><strong>Student ID:</strong> ${report.studentId}</p>
            <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
            <p><strong>Company:</strong> ${report.company}</p>
            <p><strong>Company Supervisor:</strong> ${report.supervisor}</p>
            <p><strong>Internship Period:</strong> ${report.startDate} to ${report.endDate}</p>
            <p><strong>Submission Date:</strong> ${report.submissionDate}</p>
            <p><strong>Status:</strong> <span class="status-badge status-${report.status}">
                ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
            </span></p>
            <div class="pdf-preview">
                <iframe src="${report.pdfUrl}" width="100%" height="400px"></iframe>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function viewStatistics() {
    const modal = document.getElementById('statisticsModal');
    const statisticsContent = document.getElementById('statisticsContent');

    statisticsContent.innerHTML = `
        <div class="statistics-grid">
            <div class="stat-card">
                <h3>Current Cycle Status</h3>
                <p>Accepted: ${statistics.currentCycle.accepted}</p>
                <p>Rejected: ${statistics.currentCycle.rejected}</p>
                <p>Flagged: ${statistics.currentCycle.flagged}</p>
                <p>Pending: ${statistics.currentCycle.pending}</p>
            </div>
            <div class="stat-card">
                <h3>Performance Metrics</h3>
                <p>Average Review Time: ${statistics.averageReviewTime}</p>
            </div>
            <div class="stat-card">
                <h3>Top Courses</h3>
                ${statistics.topCourses.map(course => 
                    `<p>${course.name}: ${course.count} students</p>`
                ).join('')}
            </div>
            <div class="stat-card">
                <h3>Top Rated Companies</h3>
                ${statistics.topCompanies.map(company => 
                    `<p>${company.name}: ${company.rating}/5.0</p>`
                ).join('')}
            </div>
            <div class="stat-card">
                <h3>Companies by Internship Count</h3>
                ${statistics.companiesByInternshipCount.map(company => 
                    `<p>${company.name}: ${company.count} interns</p>`
                ).join('')}
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function generateReport() {
    // Create new jsPDF instance
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Add title
    doc.setFontSize(20);
    doc.setTextColor(193, 46, 46); // #c12e2e
    doc.text("Internship Reports Statistics", 20, 20);

    // Add current date
    doc.setFontSize(10);
    doc.setTextColor(102, 102, 102); // #666666
    const date = new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    doc.text(`Generated on ${date}`, 20, 30);

    // Current Cycle Status
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text("Current Cycle Status", 20, 45);
    
    const cycleData = [
        ["Status", "Count"],
        ["Accepted", statistics.currentCycle.accepted],
        ["Rejected", statistics.currentCycle.rejected],
        ["Flagged", statistics.currentCycle.flagged],
        ["Pending", statistics.currentCycle.pending]
    ];
    
    doc.autoTable({
        startY: 50,
        head: [cycleData[0]],
        body: cycleData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Performance Metrics
    doc.text("Performance Metrics", 20, doc.lastAutoTable.finalY + 15);
    doc.setFontSize(12);
    doc.text(`Average Review Time: ${statistics.averageReviewTime}`, 20, doc.lastAutoTable.finalY + 25);

    // Top Courses
    doc.setFontSize(14);
    doc.text("Most Popular Courses", 20, doc.lastAutoTable.finalY + 35);
    
    const coursesData = [
        ["Course", "Number of Students"],
        ...statistics.topCourses.map(course => [course.name, course.count])
    ];
    
    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 40,
        head: [coursesData[0]],
        body: coursesData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Top Rated Companies
    doc.text("Top Rated Companies", 20, doc.lastAutoTable.finalY + 15);
    
    const companiesData = [
        ["Company", "Rating"],
        ...statistics.topCompanies.map(company => [company.name, `${company.rating}/5.0`])
    ];
    
    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [companiesData[0]],
        body: companiesData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Companies by Internship Count
    doc.text("Companies by Internship Count", 20, doc.lastAutoTable.finalY + 15);
    
    const internshipCountData = [
        ["Company", "Number of Interns"],
        ...statistics.companiesByInternshipCount.map(company => [company.name, company.count])
    ];
    
    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [internshipCountData[0]],
        body: internshipCountData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Add footer
    const pageCount = doc.internal.getNumberOfPages();
    doc.setFontSize(10);
    doc.setTextColor(102, 102, 102);
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.text(
            `Page ${i} of ${pageCount}`,
            doc.internal.pageSize.width / 2,
            doc.internal.pageSize.height - 10,
            { align: 'center' }
        );
    }

    // Save the PDF
    const fileName = `internship-statistics-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(fileName);
}

function approveReport() {
    // Implementation for approving reports
    alert('Report approved successfully!');
}

function rejectReport() {
    // Implementation for rejecting reports
    alert('Report rejected successfully!');
}

function flagReport() {
    // Implementation for flagging reports
    alert('Report flagged for review!');
}

function submitClarification() {
    // Implementation for submitting clarification
    const clarification = prompt('Please enter your clarification for why this report was flagged or rejected:');
    if (clarification) {
        alert('Clarification submitted successfully!');
    }
} 