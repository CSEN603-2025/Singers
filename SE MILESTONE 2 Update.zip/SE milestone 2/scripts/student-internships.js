// Sample internships
const internships = [
    {
      title: "Frontend Developer",
      company: "TechNova",
      duration: "3 months",
      location: "Cairo",
      paid: true,
      salary: "3000 EGP",
      industry: "Software",
      skills: "HTML, CSS, React",
      description: "Build user interfaces with React."
    },
    {
      title: "Marketing Intern",
      company: "Brandly",
      duration: "1 month",
      location: "Remote",
      paid: false,
      salary: "Unpaid",
      industry: "Marketing",
      skills: "Social Media, Canva",
      description: "Support our marketing team on social platforms."
    },
    {
      title: "Content Writer",
      company: "MediScope",
      duration: "2 months",
      location: "Giza",
      paid: true,
      salary: "1500 EGP",
      industry: "Media",
      skills: "SEO, Writing, WordPress",
      description: "Write and optimize content for digital publishing."
    },
    {
      title: "HR Assistant",
      company: "PeopleFirst",
      duration: "3 months",
      location: "Hybrid",
      paid: true,
      salary: "2500 EGP",
      industry: "Human Resources",
      skills: "Recruitment, Excel, Communication",
      description: "Assist with hiring and employee engagement activities."
    }
  ];
  
  // Apply filters and render
  function applyFilters() {
    const search = document.getElementById("searchInput").value.toLowerCase();
    const industry = document.getElementById("industryFilter").value;
    const duration = document.getElementById("durationFilter").value;
    const paid = document.getElementById("paidFilter").value;
  
    const filtered = internships.filter(i =>
      (i.title.toLowerCase().includes(search) || i.company.toLowerCase().includes(search)) &&
      (industry === "" || i.industry === industry) &&
      (duration === "" || i.duration === duration) &&
      (paid === "" || String(i.paid) === paid)
    );
  
    renderInternships(filtered);
  }
  
  // Render internships
  function renderInternships(data = internships) {
    const container = document.getElementById("internshipList");
    container.innerHTML = "";
  
    if (data.length === 0) {
      container.innerHTML = "<p>No internships match your criteria.</p>";
      return;
    }
  
    data.forEach(i => {
      const div = document.createElement("div");
      div.className = "card";
      div.innerHTML = `
        <h3>${i.title}</h3>
        <p><strong>Company:</strong> ${i.company}</p>
        <p><strong>Location:</strong> ${i.location}</p>
        <p><strong>Duration:</strong> ${i.duration}</p>
        <p><strong>Paid:</strong> ${i.paid ? "Yes (" + i.salary + ")" : "No"}</p>
        <p><strong>Industry:</strong> ${i.industry}</p>
        <p><strong>Skills:</strong> ${i.skills}</p>
        <p>${i.description}</p>
        <button onclick="apply('${i.title}', '${i.company}')">Apply</button>
      `;
      container.appendChild(div);
    });
  }
  
  // Simulate apply button
  function apply(title, company) {
    alert(`You applied for "${title}" at ${company}`);
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    renderInternships();
  });