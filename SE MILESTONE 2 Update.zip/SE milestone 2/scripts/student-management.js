// Dummy student data
const students = [
    {
        id: 1,
        name: "Ahmed Mohamed",
        studentId: "49-12345",
        major: "Computer Science",
        gpa: "3.7",
        status: "in_progress",
        company: "TechCorp Solutions",
        startDate: "2024-02-15",
        endDate: "2024-08-15",
        reports: [
            {
                id: 1,
                title: "February Progress Report",
                submissionDate: "2024-03-01",
                status: "submitted",
                pdfUrl: "../../assets/reports/progress-report-feb.pdf"
            }
        ]
    },
    {
        id: 2,
        name: "Sarah Ahmed",
        studentId: "49-12346",
        major: "Computer Engineering",
        gpa: "3.9",
        status: "not_started",
        company: "Pending",
        reports: []
    },
    {
        id: 3,
        name: "Omar Hassan",
        studentId: "49-12347",
        major: "Computer Science",
        gpa: "3.5",
        status: "completed",
        company: "FinanceHub",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        reports: [
            {
                id: 2,
                title: "Final Internship Report",
                submissionDate: "2024-03-01",
                status: "submitted",
                pdfUrl: "../../assets/reports/final-report.pdf"
            },
            {
                id: 3,
                title: "Mid-term Evaluation",
                submissionDate: "2023-12-15",
                status: "submitted",
                pdfUrl: "../../assets/reports/midterm-evaluation.pdf"
            }
        ]
    }
];

// Dummy reports data
const reports = [
    {
        id: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-12345",
        title: "February Progress Report",
        submissionDate: "2024-03-01",
        company: "TechCorp Solutions",
        pdfUrl: "../../assets/reports/progress-report-feb.pdf"
    },
    {
        id: 2,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        title: "Final Internship Report",
        submissionDate: "2024-03-01",
        company: "FinanceHub",
        pdfUrl: "../../assets/reports/final-report.pdf"
    },
    {
        id: 3,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        title: "Mid-term Evaluation",
        submissionDate: "2023-12-15",
        company: "FinanceHub",
        pdfUrl: "../../assets/reports/midterm-evaluation.pdf"
    }
];

document.addEventListener('DOMContentLoaded', function() {
    // Initialize date inputs with current cycle dates
    const today = new Date();
    document.getElementById('startDate').value = '2024-02-01';
    document.getElementById('endDate').value = '2024-08-01';

    // Save cycle dates
    document.querySelector('.save-cycle-btn').addEventListener('click', saveCycleDates);

    // Initialize students grid
    renderStudents(students);

    // Initialize reports list
    renderReports(reports);

    // Setup search and filter functionality
    document.getElementById('searchStudent').addEventListener('input', filterStudents);
    document.getElementById('statusFilter').addEventListener('change', filterStudents);

    // Setup modal close functionality
    const modal = document.getElementById('studentModal');
    const closeModal = document.querySelector('.close-modal');

    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
        // Close PDF viewer if open
        const pdfModal = document.getElementById('pdfViewerModal');
        if (pdfModal) {
            pdfModal.style.display = 'none';
        }
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
        const pdfModal = document.getElementById('pdfViewerModal');
        if (e.target === pdfModal) {
            pdfModal.style.display = 'none';
        }
    });

    // Initialize reports data
    renderReportsList(reports);

    // Add event listeners for filters
    const reportsStatusFilter = document.getElementById('reportsStatusFilter');
    if (reportsStatusFilter) {
        reportsStatusFilter.addEventListener('change', filterReportsList);
    }

    // Initialize navigation
    initializeNavigation();
});

function saveCycleDates() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (!startDate || !endDate) {
        alert('Please select both start and end dates');
        return;
    }

    if (new Date(startDate) >= new Date(endDate)) {
        alert('End date must be after start date');
        return;
    }

    // Here you would typically save the dates to your backend
    alert('Internship cycle dates saved successfully');
}

function renderStudents(studentsList) {
    const studentsGrid = document.getElementById('studentsGrid');
    studentsGrid.innerHTML = studentsList.map(student => `
        <div class="student-card" onclick="showStudentDetails(${student.id})">
            <h3>${student.name}</h3>
            <p class="student-info"><strong>ID:</strong> ${student.studentId}</p>
            <p class="student-info"><strong>Major:</strong> ${student.major}</p>
            <p class="student-info"><strong>Company:</strong> ${student.company}</p>
            <span class="student-status status-${student.status}">
                ${formatStatus(student.status)}
            </span>
        </div>
    `).join('');
}

function renderReports(reportsList) {
    const reportsList_el = document.getElementById('reportsList');
    reportsList_el.innerHTML = reportsList.map(report => `
        <div class="report-item">
            <div class="report-info">
                <h4>${report.title}</h4>
                <div class="report-meta">
                    <p>Student: ${report.studentName} (${report.studentId})</p>
                    <p>Submitted: ${report.submissionDate}</p>
                    <p>Company: ${report.company}</p>
                </div>
            </div>
            <div class="report-actions">
                <button class="view-report-btn" onclick="viewReport('${report.pdfUrl}', '${report.title}')">View Report</button>
            </div>
        </div>
    `).join('');
}

function showStudentDetails(studentId) {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    const modal = document.getElementById('studentModal');
    const modalStudentName = document.getElementById('modalStudentName');
    const modalStudentDetails = document.getElementById('modalStudentDetails');
    const studentReports = document.getElementById('studentReports');

    modalStudentName.textContent = student.name;
    modalStudentDetails.innerHTML = `
        <p><strong>Student ID:</strong> ${student.studentId}</p>
        <p><strong>Major:</strong> ${student.major}</p>
        <p><strong>GPA:</strong> ${student.gpa}</p>
        <p><strong>Status:</strong> <span class="student-status status-${student.status}">${formatStatus(student.status)}</span></p>
        <p><strong>Company:</strong> ${student.company}</p>
        ${student.startDate ? `<p><strong>Internship Period:</strong> ${student.startDate} to ${student.endDate}</p>` : ''}
    `;

    studentReports.innerHTML = student.reports.length ? student.reports.map(report => `
        <div class="report-item">
            <div class="report-info">
                <h4>${report.title}</h4>
                <p>Submitted: ${report.submissionDate}</p>
            </div>
            <div class="report-actions">
                <button class="view-report-btn" onclick="viewReport('${report.pdfUrl}', '${report.title}')">View Report</button>
            </div>
        </div>
    `).join('') : '<p>No reports submitted yet.</p>';

    modal.style.display = 'block';
}

function filterStudents() {
    const searchTerm = document.getElementById('searchStudent').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;

    const filteredStudents = students.filter(student => {
        const matchesSearch = student.name.toLowerCase().includes(searchTerm) ||
                            student.studentId.toLowerCase().includes(searchTerm);
        const matchesStatus = !statusFilter || student.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    renderStudents(filteredStudents);
}

function formatStatus(status) {
    return status.split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

function viewReport(pdfUrl, title) {
    // Create PDF viewer modal if it doesn't exist
    let pdfModal = document.getElementById('pdfViewerModal');
    if (!pdfModal) {
        pdfModal = document.createElement('div');
        pdfModal.id = 'pdfViewerModal';
        pdfModal.className = 'modal pdf-modal';
        pdfModal.innerHTML = `
            <div class="modal-content pdf-modal-content">
                <div class="pdf-header">
                    <h3 id="pdfTitle"></h3>
                    <span class="close-modal" onclick="closePdfViewer()">&times;</span>
                </div>
                <iframe id="pdfViewer" width="100%" height="100%" frameborder="0"></iframe>
            </div>
        `;
        document.body.appendChild(pdfModal);
    }

    // Update PDF viewer content
    document.getElementById('pdfTitle').textContent = title;
    const pdfViewer = document.getElementById('pdfViewer');
    pdfViewer.src = pdfUrl;
    pdfModal.style.display = 'block';
}

function closePdfViewer() {
    const pdfModal = document.getElementById('pdfViewerModal');
    if (pdfModal) {
        pdfModal.style.display = 'none';
    }
}

function initializeNavigation() {
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            const tabName = this.getAttribute('data-tab');
            navigateToTab(tabName);
        });
    });
}

function navigateToTab(tabName) {
    switch(tabName) {
        case 'companies':
            window.location.href = '../../pages/scad-dashboard.html';
            break;
        case 'students':
            // Already on student management page
            break;
        case 'reports':
            const studentsSection = document.getElementById('studentsSection');
            const reportsSection = document.getElementById('reportsSection');
            
            if (studentsSection && reportsSection) {
                studentsSection.style.display = 'none';
                reportsSection.style.display = 'block';
            }
            break;
    }

    // Update active tab
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
}

function renderReportsList(reportsList) {
    const reportsListContainer = document.getElementById('reportsList');
    if (!reportsListContainer) return;

    reportsListContainer.innerHTML = reportsList.map(report => `
        <div class="report-item" onclick="showReportDetails(${report.id})">
            <div class="report-info">
                <div class="report-title">${report.title}</div>
                <div class="report-meta">
                    <span>Student: ${report.studentName} (${report.studentId})</span>
                    <span> • </span>
                    <span>Submitted: ${report.submissionDate}</span>
                </div>
            </div>
            <span class="report-status status-${report.status}">
                ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
            </span>
        </div>
    `).join('');
}

function filterReportsList() {
    const selectedStatus = document.getElementById('reportsStatusFilter').value;
    const filteredReports = selectedStatus 
        ? reports.filter(report => report.status === selectedStatus)
        : reports;
    
    renderReportsList(filteredReports);
}

function showReportDetails(reportId) {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    const modal = document.getElementById('studentModal');
    const modalStudentName = document.getElementById('modalStudentName');
    const modalStudentDetails = document.getElementById('modalStudentDetails');

    modalStudentName.textContent = report.studentName;
    modalStudentDetails.innerHTML = `
        <div class="report-details">
            <h3>${report.title}</h3>
            <p><strong>Student ID:</strong> ${report.studentId}</p>
            <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
            <p><strong>Company:</strong> ${report.company}</p>
            <p><strong>Submission Date:</strong> ${report.submissionDate}</p>
            <p><strong>Status:</strong> <span class="status-badge status-${report.status}">
                ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
            </span></p>
            <div class="pdf-preview">
                <iframe src="${report.pdfUrl}" width="100%" height="400px"></iframe>
            </div>
        </div>
    `;

    modal.style.display = 'block';
} 