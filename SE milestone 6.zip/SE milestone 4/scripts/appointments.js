// Dummy data for appointments
let appointments = [
    {
        id: 1,
        title: "Career Guidance Session",
        date: "2024-03-25",
        time: "10:00",
        description: "Discussion about internship opportunities in software development",
        status: "active",
        capacity: 10,
        currentAttendees: 3
    },
    {
        id: 2,
        title: "Resume Review",
        date: "2024-03-26",
        time: "14:30",
        description: "Review and feedback on student's resume for tech internships",
        status: "active",
        capacity: 5,
        currentAttendees: 5
    },
    {
        id: 3,
        title: "Mock Interview",
        date: "2024-03-27",
        time: "11:00",
        description: "Practice interview for upcoming internship applications",
        status: "active",
        capacity: 8,
        currentAttendees: 4
    }
];

// Dummy data for student requests
let studentRequests = [
    {
        id: 1,
        appointmentId: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-1234",
        requestDate: "2024-03-20",
        status: "pending"
    },
    {
        id: 2,
        appointmentId: 1,
        studentName: "Sara Ahmed",
        studentId: "49-5678",
        requestDate: "2024-03-21",
        status: "pending"
    },
    {
        id: 3,
        appointmentId: 3,
        studentName: "Omar Hassan",
        studentId: "49-9012",
        requestDate: "2024-03-22",
        status: "pending"
    }
];

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    renderAppointments();
    renderStudentRequests();
});

// Render all appointments
function renderAppointments() {
    const grid = document.getElementById('appointmentsGrid');
    grid.innerHTML = '';

    appointments.forEach(appointment => {
        const card = createAppointmentCard(appointment);
        grid.appendChild(card);
    });
}

// Create a card element for an appointment
function createAppointmentCard(appointment) {
    const card = document.createElement('div');
    card.className = 'appointment-card';
    
    const datetime = new Date(`${appointment.date}T${appointment.time}`);
    const formattedDate = datetime.toLocaleDateString('en-US', { 
        weekday: 'short', 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
    const formattedTime = datetime.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });

    card.innerHTML = `
        <h3>${appointment.title}</h3>
        <p class="appointment-info">${appointment.description}</p>
        <div class="appointment-datetime">
            <span>${formattedDate}</span>
            <span>${formattedTime}</span>
        </div>
        <div class="capacity-info">
            <span class="icon">👥</span>
            <span>${appointment.currentAttendees}/${appointment.capacity} Attendees</span>
        </div>
        <div class="appointment-actions">
            <button class="btn-action btn-edit" onclick="editAppointment(${appointment.id})">Edit</button>
            <button class="btn-action btn-delete" onclick="deleteAppointment(${appointment.id})">Delete</button>
        </div>
    `;

    return card;
}

// Render student requests
function renderStudentRequests() {
    const requestsList = document.getElementById('requestsList');
    requestsList.innerHTML = '';

    studentRequests.forEach(request => {
        if (request.status === 'pending') {
            const appointment = appointments.find(a => a.id === request.appointmentId);
            const requestElement = createRequestElement(request, appointment);
            requestsList.appendChild(requestElement);
        }
    });
}

// Create a request element
function createRequestElement(request, appointment) {
    const element = document.createElement('div');
    element.className = 'request-item';
    
    element.innerHTML = `
        <div class="request-info">
            <h4>${appointment.title}</h4>
            <p>Student: ${request.studentName} (${request.studentId})</p>
            <p>Requested on: ${new Date(request.requestDate).toLocaleDateString()}</p>
        </div>
        <div class="request-actions">
            <button class="btn-accept" onclick="handleRequest(${request.id}, 'accept')">Accept</button>
            <button class="btn-reject" onclick="handleRequest(${request.id}, 'reject')">Reject</button>
        </div>
    `;

    return element;
}

// Handle student request
function handleRequest(requestId, action) {
    const request = studentRequests.find(r => r.id === requestId);
    if (!request) return;

    const appointment = appointments.find(a => a.id === request.appointmentId);
    if (!appointment) return;

    if (action === 'accept') {
        if (appointment.currentAttendees < appointment.capacity) {
            request.status = 'accepted';
            appointment.currentAttendees++;
        } else {
            alert('This appointment has reached its maximum capacity.');
            return;
        }
    } else {
        request.status = 'rejected';
    }

    renderAppointments();
    renderStudentRequests();
}

// Modal handling
function openAddAppointmentModal() {
    const modal = document.getElementById('appointmentModal');
    const form = document.getElementById('appointmentForm');
    const modalTitle = document.getElementById('modalTitle');
    
    modalTitle.textContent = 'Add New Appointment';
    form.reset();
    form.removeAttribute('data-id');
    
    modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('appointmentModal');
    modal.style.display = 'none';
}

// Form submission handling
function handleAppointmentSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const appointmentData = {
        id: form.hasAttribute('data-id') ? parseInt(form.getAttribute('data-id')) : appointments.length + 1,
        title: formData.get('title'),
        date: formData.get('date'),
        time: formData.get('time'),
        description: formData.get('description'),
        capacity: parseInt(formData.get('capacity')),
        currentAttendees: form.hasAttribute('data-id') ? 
            appointments.find(a => a.id === parseInt(form.getAttribute('data-id'))).currentAttendees : 
            0,
        status: 'active'
    };

    if (form.hasAttribute('data-id')) {
        // Update existing appointment
        const index = appointments.findIndex(a => a.id === appointmentData.id);
        appointments[index] = appointmentData;
    } else {
        // Add new appointment
        appointments.push(appointmentData);
    }

    renderAppointments();
    closeModal();
}

// Edit appointment
function editAppointment(id) {
    const appointment = appointments.find(a => a.id === id);
    if (!appointment) return;

    const modal = document.getElementById('appointmentModal');
    const form = document.getElementById('appointmentForm');
    const modalTitle = document.getElementById('modalTitle');

    modalTitle.textContent = 'Edit Appointment';
    form.setAttribute('data-id', id);
    
    document.getElementById('title').value = appointment.title;
    document.getElementById('date').value = appointment.date;
    document.getElementById('time').value = appointment.time;
    document.getElementById('description').value = appointment.description;
    document.getElementById('capacity').value = appointment.capacity;

    modal.style.display = 'flex';
}

// Delete appointment
function deleteAppointment(id) {
    if (confirm('Are you sure you want to delete this appointment?')) {
        appointments = appointments.filter(a => a.id !== id);
        studentRequests = studentRequests.filter(r => r.appointmentId !== id);
        renderAppointments();
        renderStudentRequests();
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('appointmentModal');
    if (event.target === modal) {
        closeModal();
    }
} 