// Load from localStorage or initialize with dummy data
let interns = JSON.parse(localStorage.getItem("interns")) || [
  {
    name: "Laila Mansour",
    email: "laila@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "current intern",
    skills: "Adobe XD, Illustrator, Creativity",
    resume: "../../assets/dummy-cv.pdf",
    description: "Looking forward to contributing to TechNova's branding."
  },
  {
    name: "Youssef Hatem",
    email: "youssef@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "internship complete",
    skills: "React, JavaScript, HTML",
    resume: "../../assets/dummy-cv.pdf",
    description: "Loved working on the UI for internal dashboards.",
    evaluation: {
      rating: 5,
      technicalSkills: 5,
      communication: 4,
      initiative: 5,
      teamwork: 4,
      feedback: "Outstanding performance in frontend development. Created reusable components and improved our development workflow.",
      recommendHire: true,
      recommendIntern: true
    }
  },
  {
    name: "Sara Helmy",
    email: "sara@student.guc.edu.eg",
    post: "Marketing Intern",
    status: "internship complete",
    skills: "SEO, Social Media, Google Analytics",
    resume: "../../assets/dummy-cv.pdf",
    description: "Helped boost engagement by 20% through targeted posts.",
  },
  {
    name: "Omar Fathy",
    email: "omar@student.guc.edu.eg",
    post: "Backend Developer Intern",
    status: "current intern",
    skills: "Node.js, MongoDB, Express",
    resume: "../../assets/dummy-cv.pdf",
    description: "Eager to apply backend development skills in a real project."
  }
];

let filtered = [...interns];
let currentEvalIndex = null;

function navigateTo(page) {
  window.location.href = `../company/${page}.html`;
}

function filterInterns() {
  const query = document.getElementById("searchName").value.toLowerCase();
  const status = document.getElementById("statusFilter").value;

  filtered = interns.filter(intern =>
    (status === "" || intern.status === status) &&
    (intern.name.toLowerCase().includes(query) || intern.post.toLowerCase().includes(query))
  );

  renderInterns();
}

function viewProfile(cvUrl) {
  window.open(cvUrl, "_blank");
}

function changeStatus(index) {
  const intern = filtered[index];
  const originalIndex = interns.findIndex(i => i.email === intern.email);
  
  if (intern.status === "current intern") {
    intern.status = "internship complete";
    interns[originalIndex].status = "internship complete";
  }
  
  localStorage.setItem("interns", JSON.stringify(interns));
  renderInterns();
}

function evaluateIntern(index) {
  currentEvalIndex = index;
  const intern = filtered[index];
  
  // Fill in existing evaluation data if it exists
  if (intern.evaluation) {
    document.getElementById("performanceRating").value = intern.evaluation.rating || "";
    document.getElementById("technicalSkills").value = intern.evaluation.technicalSkills || 3;
    document.getElementById("communication").value = intern.evaluation.communication || 3;
    document.getElementById("initiative").value = intern.evaluation.initiative || 3;
    document.getElementById("teamwork").value = intern.evaluation.teamwork || 3;
    document.getElementById("evaluationText").value = intern.evaluation.feedback || "";
    document.getElementById("recommendHire").checked = intern.evaluation.recommendHire || false;
    document.getElementById("recommendIntern").checked = intern.evaluation.recommendIntern || false;
    
    // Update range value displays
    document.querySelectorAll('.skill-item input[type="range"]').forEach(input => {
      input.nextElementSibling.textContent = input.value;
    });
  }

  // Show delete button only if evaluation exists
  document.getElementById("deleteEvalBtn").style.display = intern.evaluation ? "block" : "none";
  
  document.getElementById("evaluationModal").classList.remove("hidden");
}

function closeEvaluationModal() {
  document.getElementById("evaluationModal").classList.add("hidden");
  currentEvalIndex = null;
}

function deleteEvaluation() {
  if (!confirm("Are you sure you want to delete this evaluation?")) return;

  const intern = filtered[currentEvalIndex];
  const originalIndex = interns.findIndex(i => i.email === intern.email);
  
  // Remove evaluation
  delete intern.evaluation;
  delete interns[originalIndex].evaluation;
  
  localStorage.setItem("interns", JSON.stringify(interns));
  alert("Evaluation posted successfully!");
  closeEvaluationModal();
  renderInterns();
}

function submitEvaluation() {
  const rating = document.getElementById("performanceRating").value;
  if (!rating) return alert("Please select a performance rating.");

  const evaluation = {
    rating: parseInt(rating),
    technicalSkills: parseInt(document.getElementById("technicalSkills").value),
    communication: parseInt(document.getElementById("communication").value),
    initiative: parseInt(document.getElementById("initiative").value),
    teamwork: parseInt(document.getElementById("teamwork").value),
    feedback: document.getElementById("evaluationText").value.trim(),
    recommendHire: document.getElementById("recommendHire").checked,
    recommendIntern: document.getElementById("recommendIntern").checked
  };

  if (!evaluation.feedback) return alert("Please provide detailed feedback.");

  // Save to filtered and main list
  filtered[currentEvalIndex].evaluation = evaluation;
  const originalIndex = interns.findIndex(i => i.email === filtered[currentEvalIndex].email);
  interns[originalIndex] = { ...filtered[currentEvalIndex] };

  localStorage.setItem("interns", JSON.stringify(interns));
  alert("Evaluation submitted successfully!");
  closeEvaluationModal();
  renderInterns();
}

// Add event listeners for range inputs
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.skill-item input[type="range"]').forEach(input => {
    input.addEventListener('input', (e) => {
      e.target.nextElementSibling.textContent = e.target.value;
    });
  });
});

// Add this new function for viewing evaluation details
function viewEvaluation(index) {
  const intern = filtered[index];
  if (!intern.evaluation) return;

  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.id = 'viewEvaluationModal';
  
  modal.innerHTML = `
    <div class="modal-content">
      <h3>Evaluation Summary</h3>
      <div class="evaluation-details">
        <p><strong>Overall Rating:</strong> ${intern.evaluation.rating}/5</p>
        <h4>Skills Assessment:</h4>
        <ul>
          <li>Technical Skills: ${intern.evaluation.technicalSkills}/5</li>
          <li>Communication: ${intern.evaluation.communication}/5</li>
          <li>Initiative: ${intern.evaluation.initiative}/5</li>
          <li>Teamwork: ${intern.evaluation.teamwork}/5</li>
        </ul>
        <p><strong>Feedback:</strong> ${intern.evaluation.feedback}</p>
        <h4>Recommendations:</h4>
        <ul>
          <li>${intern.evaluation.recommendHire ? '✓' : '✗'} Recommended for full-time position</li>
          <li>${intern.evaluation.recommendIntern ? '✓' : '✗'} Recommended for future internships</li>
        </ul>
      </div>
      <div class="modal-actions">
        <button class="btn-secondary" onclick="closeViewEvaluationModal()">Close</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
}

function closeViewEvaluationModal() {
  const modal = document.getElementById('viewEvaluationModal');
  if (modal) {
    modal.remove();
  }
}

function renderInterns() {
  const container = document.getElementById("internsContainer");
  container.innerHTML = "";

  if (filtered.length === 0) {
    container.innerHTML = "<p>No interns found.</p>";
    return;
  }

  filtered.forEach((intern, i) => {
    const div = document.createElement("div");
    div.className = "post-card";
    
    let evaluationSummary = '';
    if (intern.evaluation) {
      evaluationSummary = `
        <div class="evaluation-summary">
          <p><strong>Overall Rating:</strong> ${intern.evaluation.rating}/5</p>
        </div>
      `;
    }

    div.innerHTML = `
      <h3>${intern.name}</h3>
      <p><strong>Job Title:</strong> ${intern.post}</p>
      <p><strong>Status:</strong> <span class="badge ${intern.status.replaceAll(" ", "-")}">${intern.status}</span></p>
      <p><strong>Email:</strong> ${intern.email}</p>
      <p><strong>Skills:</strong> ${intern.skills}</p>
      ${evaluationSummary}
      <div class="status-buttons">
        <button class="grey" onclick="viewProfile('${intern.resume}')">View Profile</button>
        ${intern.status === "current intern" 
          ? `<button class="btn-primary" onclick="changeStatus(${i})">Mark as Complete</button>` 
          : `
            <button class="green" onclick="evaluateIntern(${i})">${intern.evaluation ? 'Edit' : 'Add'} Evaluation</button>
            ${intern.evaluation ? `<button class="btn-secondary" onclick="viewEvaluation(${i})">View Evaluation</button>` : ''}
          `}
      </div>
    `;
    container.appendChild(div);
  });
}

document.addEventListener("DOMContentLoaded", renderInterns);