// Dummy data for internships
const internships = [
    {
        id: 1,
        title: "Software Development Intern",
        company: "Tech Solutions Inc.",
        industry: "tech",
        duration: "3-6",
        compensation: "paid",
        salary: "5000 EGP/month",
        location: "Cairo, Egypt",
        description: "Join our dynamic team to work on cutting-edge web applications using modern technologies.",
        requirements: [
            "Currently pursuing a degree in Computer Science or related field",
            "Knowledge of JavaScript, HTML, and CSS",
            "Basic understanding of React or Angular",
            "Good problem-solving skills"
        ]
    },
    {
        id: 2,
        title: "Financial Analyst Intern",
        company: "Global Finance Corp",
        industry: "finance",
        duration: "2-3",
        compensation: "paid",
        salary: "4000 EGP/month",
        location: "New Cairo, Egypt",
        description: "Assist in financial analysis, reporting, and market research projects.",
        requirements: [
            "Business, Finance, or Economics major",
            "Strong analytical skills",
            "Proficiency in Excel",
            "Understanding of financial markets"
        ]
    },
    {
        id: 3,
        title: "Healthcare Data Analyst",
        company: "HealthTech Solutions",
        industry: "healthcare",
        duration: "1-2",
        compensation: "unpaid",
        location: "Giza, Egypt",
        description: "Work with healthcare data to improve patient care and operational efficiency.",
        requirements: [
            "Background in Healthcare Management or Data Science",
            "Knowledge of SQL and data analysis",
            "Understanding of healthcare systems",
            "Strong attention to detail"
        ]
    }
];

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    displayInternships(internships);
    setupSearchAndFilters();
});

// Display internships
function displayInternships(internshipsToShow) {
    const internshipsList = document.getElementById('internshipsList');
    internshipsList.innerHTML = '';

    internshipsToShow.forEach(internship => {
        const card = document.createElement('div');
        card.className = 'internship-card';
        card.onclick = () => showInternshipDetails(internship);

        card.innerHTML = `
            <div class="internship-header">
                <div>
                    <h3 class="internship-title">${internship.title}</h3>
                    <p class="company-name">${internship.company}</p>
                </div>
                <span class="internship-type">${internship.industry.toUpperCase()}</span>
            </div>
            <div class="internship-details">
                <div class="detail-item">
                    <span class="detail-label">Duration</span>
                    <span class="detail-value">${internship.duration} Months</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Location</span>
                    <span class="detail-value">${internship.location}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Compensation</span>
                    <span class="detail-value ${internship.compensation === 'paid' ? 'compensation-paid' : 'compensation-unpaid'}">
                        ${internship.compensation === 'paid' ? internship.salary : 'Unpaid'}
                    </span>
                </div>
            </div>
        `;

        internshipsList.appendChild(card);
    });
}

// Setup search and filters
function setupSearchAndFilters() {
    const searchTitle = document.getElementById('searchTitle');
    const searchCompany = document.getElementById('searchCompany');
    const industryFilter = document.getElementById('industryFilter');
    const durationFilter = document.getElementById('durationFilter');
    const compensationFilter = document.getElementById('compensationFilter');

    const filterInternships = () => {
        let filtered = internships;

        // Title search
        if (searchTitle.value) {
            filtered = filtered.filter(internship => 
                internship.title.toLowerCase().includes(searchTitle.value.toLowerCase())
            );
        }

        // Company search
        if (searchCompany.value) {
            filtered = filtered.filter(internship => 
                internship.company.toLowerCase().includes(searchCompany.value.toLowerCase())
            );
        }

        // Industry filter
        if (industryFilter.value) {
            filtered = filtered.filter(internship => internship.industry === industryFilter.value);
        }

        // Duration filter
        if (durationFilter.value) {
            filtered = filtered.filter(internship => internship.duration === durationFilter.value);
        }

        // Compensation filter
        if (compensationFilter.value) {
            filtered = filtered.filter(internship => internship.compensation === compensationFilter.value);
        }

        displayInternships(filtered);
    };

    // Add event listeners
    searchTitle.addEventListener('input', filterInternships);
    searchCompany.addEventListener('input', filterInternships);
    industryFilter.addEventListener('change', filterInternships);
    durationFilter.addEventListener('change', filterInternships);
    compensationFilter.addEventListener('change', filterInternships);
}

// Show internship details in modal
function showInternshipDetails(internship) {
    const modal = document.getElementById('internshipModal');
    const title = document.getElementById('modalInternshipTitle');
    const details = document.getElementById('modalInternshipDetails');

    title.textContent = internship.title;
    details.innerHTML = `
        <div class="internship-details-modal">
            <h3>Company</h3>
            <p>${internship.company}</p>

            <h3>Location</h3>
            <p>${internship.location}</p>

            <h3>Duration</h3>
            <p>${internship.duration} Months</p>

            <h3>Compensation</h3>
            <p class="${internship.compensation === 'paid' ? 'compensation-paid' : 'compensation-unpaid'}">
                ${internship.compensation === 'paid' ? internship.salary : 'Unpaid'}
            </p>

            <h3>Description</h3>
            <p>${internship.description}</p>

            <h3>Requirements</h3>
            <ul class="requirements-list">
                ${internship.requirements.map(req => `<li>${req}</li>`).join('')}
            </ul>
        </div>
    `;

    modal.style.display = 'block';
}

// Close internship details modal
function closeInternshipModal() {
    document.getElementById('internshipModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('internshipModal');
    if (event.target == modal) {
        closeInternshipModal();
    }
} 