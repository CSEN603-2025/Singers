// Dummy reports data with realistic information
const reports = [
    {
        id: 1,
        studentName: "Ahmed Mohamed",
        studentId: "49-12345",
        major: "cs",
        title: "February Progress Report",
        submissionDate: "2024-03-01",
        company: "TechCorp Solutions",
        supervisor: "John Smith",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "pending",
        content: {
            technicalSkills: ["React", "Node.js", "MongoDB"],
            projectDescription: "Developing a customer management system",
            learningOutcomes: "Improved full-stack development skills",
            challenges: "Integration with legacy systems"
        }
    },
    {
        id: 2,
        studentName: "Sarah Ahmed",
        studentId: "49-12346",
        major: "iet",
        title: "Final Internship Report",
        submissionDate: "2024-03-15",
        company: "FinanceHub",
        supervisor: "Mary Johnson",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        status: "flagged",
        content: {
            technicalSkills: ["Python", "Data Analysis", "SQL"],
            projectDescription: "Financial data visualization platform",
            learningOutcomes: "Enhanced data analysis capabilities",
            challenges: "Complex data processing requirements"
        }
    },
    {
        id: 3,
        studentName: "Omar Hassan",
        studentId: "49-12347",
        major: "dmet",
        title: "Mid-term Evaluation",
        submissionDate: "2024-02-15",
        company: "HealthCare Plus",
        supervisor: "David Wilson",
        startDate: "2024-01-01",
        endDate: "2024-07-01",
        status: "accepted",
        content: {
            technicalSkills: ["UI/UX Design", "Adobe XD", "Flutter"],
            projectDescription: "Mobile healthcare application design",
            learningOutcomes: "Mastered mobile-first design principles",
            challenges: "Accessibility compliance"
        }
    },
    {
        id: 4,
        studentName: "Nour Ibrahim",
        studentId: "49-12348",
        major: "cs",
        title: "Monthly Progress Report",
        submissionDate: "2024-03-10",
        company: "CloudTech Solutions",
        supervisor: "Emily Brown",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        status: "rejected",
        content: {
            technicalSkills: ["AWS", "Docker", "Kubernetes"],
            projectDescription: "Cloud infrastructure automation",
            learningOutcomes: "Cloud architecture expertise",
            challenges: "System scalability issues"
        }
    },
    {
        id: 5,
        studentName: "Youssef Ali",
        studentId: "49-12349",
        major: "iet",
        title: "Final Report",
        submissionDate: "2024-03-05",
        company: "SmartSystems Inc",
        supervisor: "Michael Chen",
        startDate: "2023-09-15",
        endDate: "2024-03-15",
        status: "accepted",
        content: {
            technicalSkills: ["IoT", "Embedded Systems", "C++"],
            projectDescription: "Smart home automation system",
            learningOutcomes: "Hardware-software integration",
            challenges: "Power consumption optimization"
        }
    }
];

// Enhanced Statistics data
const statistics = {
    currentCycle: {
        total: 50,
        accepted: 25,
        rejected: 8,
        flagged: 7,
        pending: 10
    },
    byMajor: {
        cs: 20,
        iet: 15,
        dmet: 15
    },
    byMonth: {
        'Jan 2024': { total: 40, accepted: 20, rejected: 5 },
        'Feb 2024': { total: 45, accepted: 22, rejected: 6 },
        'Mar 2024': { total: 50, accepted: 25, rejected: 8 }
    },
    averageMetrics: {
        reviewTime: "3.5 days",
        completionRate: "85%",
        acceptanceRate: "72%",
        revisionRate: "15%"
    },
    topCompanies: [
        { name: "TechCorp Solutions", count: 12, rating: 4.8, acceptanceRate: "92%" },
        { name: "FinanceHub", count: 8, rating: 4.6, acceptanceRate: "88%" },
        { name: "CloudTech Solutions", count: 7, rating: 4.7, acceptanceRate: "90%" }
    ],
    facultyPerformance: {
        totalReviewed: 42,
        averageResponseTime: "2.1 days",
        activeReviewers: 8
    }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initial render of reports
    renderReports(reports);

    // Setup search and filter functionality
    setupFilters();
});

function renderReports(reportsList) {
    const reportsGrid = document.getElementById('reportsGrid');
    reportsGrid.innerHTML = reportsList.map(report => `
        <div class="report-item" data-report-id="${report.id}">
            <div class="report-summary" onclick="toggleReportDetails(${report.id})">
                <div class="report-title">
                    <h3>${report.title}</h3>
                    <span class="report-status status-${report.status}">
                        ${report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                    </span>
                </div>
                <div class="report-meta">
                    <p><strong>Student:</strong> ${report.studentName} (${report.studentId})</p>
                    <p><strong>Major:</strong> ${report.major.toUpperCase()}</p>
                    <p><strong>Company:</strong> ${report.company}</p>
                    <p><strong>Submitted:</strong> ${report.submissionDate}</p>
                </div>
                <div class="expand-icon">▼</div>
            </div>
            <div class="report-details" id="report-details-${report.id}" style="display: none;">
                <div class="report-info">
                    <p><strong>Supervisor:</strong> ${report.supervisor}</p>
                    <p><strong>Internship Period:</strong> ${report.startDate} to ${report.endDate}</p>
                </div>
                <div class="report-content">
                    <div class="content-section">
                        <h4>Technical Skills</h4>
                        <p>${report.content.technicalSkills.join(', ')}</p>
                    </div>
                    
                    <div class="content-section">
                        <h4>Project Description</h4>
                        <p>${report.content.projectDescription}</p>
                    </div>
                    
                    <div class="content-section">
                        <h4>Learning Outcomes</h4>
                        <p>${report.content.learningOutcomes}</p>
                    </div>
                    
                    <div class="content-section">
                        <h4>Challenges</h4>
                        <p>${report.content.challenges}</p>
                    </div>
                </div>
                <div class="action-buttons">
                    <button class="btn btn-approve" onclick="approveReport(${report.id})">Accept Report</button>
                    <button class="btn btn-reject" onclick="rejectReport(${report.id})">Reject Report</button>
                    <button class="btn btn-flag" onclick="flagReport(${report.id})">Flag for Review</button>
                    <button class="btn btn-clarify" onclick="submitClarification(${report.id})">Request Clarification</button>
                </div>
            </div>
        </div>
    `).join('');
}

function toggleReportDetails(reportId) {
    const detailsElement = document.getElementById(`report-details-${reportId}`);
    const reportItem = detailsElement.closest('.report-item');
    const expandIcon = reportItem.querySelector('.expand-icon');
    
    if (detailsElement.style.display === 'none') {
        detailsElement.style.display = 'block';
        expandIcon.style.transform = 'rotate(180deg)';
        reportItem.classList.add('expanded');
    } else {
        detailsElement.style.display = 'none';
        expandIcon.style.transform = 'rotate(0deg)';
        reportItem.classList.remove('expanded');
    }
}

function setupFilters() {
    const searchInput = document.getElementById('searchReport');
    const majorFilter = document.getElementById('majorFilter');
    const statusFilter = document.getElementById('reportStatusFilter');

    const filterReports = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedMajor = majorFilter.value;
        const selectedStatus = statusFilter.value;

        const filteredReports = reports.filter(report => {
            const matchesSearch = 
                report.studentName.toLowerCase().includes(searchTerm) ||
                report.studentId.toLowerCase().includes(searchTerm) ||
                report.company.toLowerCase().includes(searchTerm);
            const matchesMajor = !selectedMajor || report.major === selectedMajor;
            const matchesStatus = !selectedStatus || report.status === selectedStatus;
            
            return matchesSearch && matchesMajor && matchesStatus;
        });

        renderReports(filteredReports);
    };

    searchInput.addEventListener('input', filterReports);
    majorFilter.addEventListener('change', filterReports);
    statusFilter.addEventListener('change', filterReports);
}

function viewStatistics() {
    const modal = document.getElementById('statisticsModal');
    const statisticsContent = document.getElementById('statisticsContent');

    statisticsContent.innerHTML = `
        <div class="statistics-grid">
            <div class="stat-card">
                <h3>Current Cycle Overview</h3>
                <div class="stat-content">
                    <p>Total Reports: ${statistics.currentCycle.total}</p>
                    <p>Accepted: ${statistics.currentCycle.accepted}</p>
                    <p>Rejected: ${statistics.currentCycle.rejected}</p>
                    <p>Flagged: ${statistics.currentCycle.flagged}</p>
                    <p>Pending: ${statistics.currentCycle.pending}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Distribution by Major</h3>
                <div class="stat-content">
                    <p>Computer Science: ${statistics.byMajor.cs}</p>
                    <p>IET: ${statistics.byMajor.iet}</p>
                    <p>DMET: ${statistics.byMajor.dmet}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Monthly Trends</h3>
                <div class="stat-content">
                    ${Object.entries(statistics.byMonth).map(([month, data]) => `
                        <div class="month-stat">
                            <h4>${month}</h4>
                            <p>Total: ${data.total}</p>
                            <p>Accepted: ${data.accepted}</p>
                            <p>Rejected: ${data.rejected}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="stat-card">
                <h3>Performance Metrics</h3>
                <div class="stat-content">
                    <p>Average Review Time: ${statistics.averageMetrics.reviewTime}</p>
                    <p>Completion Rate: ${statistics.averageMetrics.completionRate}</p>
                    <p>Acceptance Rate: ${statistics.averageMetrics.acceptanceRate}</p>
                    <p>Revision Rate: ${statistics.averageMetrics.revisionRate}</p>
                </div>
            </div>
            <div class="stat-card">
                <h3>Top Companies</h3>
                <div class="stat-content">
                    ${statistics.topCompanies.map(company => `
                        <div class="company-stat">
                            <p>${company.name}</p>
                            <p>Interns: ${company.count}</p>
                            <p>Rating: ${company.rating}/5.0</p>
                            <p>Acceptance Rate: ${company.acceptanceRate}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="stat-card">
                <h3>Faculty Performance</h3>
                <div class="stat-content">
                    <p>Total Reviews: ${statistics.facultyPerformance.totalReviewed}</p>
                    <p>Average Response Time: ${statistics.facultyPerformance.averageResponseTime}</p>
                    <p>Active Reviewers: ${statistics.facultyPerformance.activeReviewers}</p>
                </div>
            </div>
        </div>
    `;

    modal.style.display = 'block';
}

function generateReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Add title and header
    doc.setFontSize(20);
    doc.setTextColor(193, 46, 46); // GUC Red
    doc.text('Internship Reports Analytics', 20, 20);

    // Add current date
    doc.setFontSize(12);
    doc.setTextColor(102, 102, 102);
    const date = new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    doc.text(`Generated on ${date}`, 20, 30);

    // Current Cycle Overview
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('Current Cycle Overview', 20, 45);
    
    const cycleData = [
        ['Status', 'Count', 'Percentage'],
        ['Accepted', statistics.currentCycle.accepted, `${(statistics.currentCycle.accepted/statistics.currentCycle.total*100).toFixed(1)}%`],
        ['Rejected', statistics.currentCycle.rejected, `${(statistics.currentCycle.rejected/statistics.currentCycle.total*100).toFixed(1)}%`],
        ['Flagged', statistics.currentCycle.flagged, `${(statistics.currentCycle.flagged/statistics.currentCycle.total*100).toFixed(1)}%`],
        ['Pending', statistics.currentCycle.pending, `${(statistics.currentCycle.pending/statistics.currentCycle.total*100).toFixed(1)}%`]
    ];

    doc.autoTable({
        startY: 50,
        head: [cycleData[0]],
        body: cycleData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Distribution by Major
    doc.text('Distribution by Major', 20, doc.lastAutoTable.finalY + 15);
    
    const majorData = [
        ['Major', 'Count', 'Percentage'],
        ['Computer Science', statistics.byMajor.cs, `${(statistics.byMajor.cs/statistics.currentCycle.total*100).toFixed(1)}%`],
        ['IET', statistics.byMajor.iet, `${(statistics.byMajor.iet/statistics.currentCycle.total*100).toFixed(1)}%`],
        ['DMET', statistics.byMajor.dmet, `${(statistics.byMajor.dmet/statistics.currentCycle.total*100).toFixed(1)}%`]
    ];

    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [majorData[0]],
        body: majorData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Monthly Trends
    doc.text('Monthly Trends', 20, doc.lastAutoTable.finalY + 15);
    
    const monthlyData = [
        ['Month', 'Total', 'Accepted', 'Rejected', 'Acceptance Rate'],
        ...Object.entries(statistics.byMonth).map(([month, data]) => [
            month,
            data.total,
            data.accepted,
            data.rejected,
            `${(data.accepted/data.total*100).toFixed(1)}%`
        ])
    ];

    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [monthlyData[0]],
        body: monthlyData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Performance Metrics
    doc.text('Performance Metrics', 20, doc.lastAutoTable.finalY + 15);
    
    const metricsData = [
        ['Metric', 'Value'],
        ['Average Review Time', statistics.averageMetrics.reviewTime],
        ['Completion Rate', statistics.averageMetrics.completionRate],
        ['Acceptance Rate', statistics.averageMetrics.acceptanceRate],
        ['Revision Rate', statistics.averageMetrics.revisionRate]
    ];

    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [metricsData[0]],
        body: metricsData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Top Companies
    doc.text('Top Companies Performance', 20, doc.lastAutoTable.finalY + 15);
    
    const companiesData = [
        ['Company', 'Interns', 'Rating', 'Acceptance Rate'],
        ...statistics.topCompanies.map(company => [
            company.name,
            company.count,
            `${company.rating}/5.0`,
            company.acceptanceRate
        ])
    ];

    doc.autoTable({
        startY: doc.lastAutoTable.finalY + 20,
        head: [companiesData[0]],
        body: companiesData.slice(1),
        theme: 'grid',
        headStyles: { fillColor: [193, 46, 46] }
    });

    // Add page numbers
    const pageCount = doc.internal.getNumberOfPages();
    for(let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        doc.setTextColor(150);
        doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width - 30, doc.internal.pageSize.height - 10);
    }

    // Save the PDF
    const fileName = `internship-analytics-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(fileName);
}

function approveReport(reportId) {
    alert('Report approved successfully!');
    // Here you would typically update the report status in your backend
}

function rejectReport(reportId) {
    const reason = prompt('Please enter the reason for rejection:');
    if (reason) {
        alert('Report rejected successfully!');
        // Here you would typically update the report status in your backend
    }
}

function flagReport(reportId) {
    const reason = prompt('Please enter the reason for flagging this report:');
    if (reason) {
        alert('Report flagged for review!');
        // Here you would typically update the report status in your backend
    }
}

function submitClarification(reportId) {
    const clarification = prompt('Please enter your clarification request:');
    if (clarification) {
        alert('Clarification request submitted successfully!');
        // Here you would typically send the clarification to your backend
    }
} 