// Available positions data (simulating a database)
const availablePositions = {
  "TechNova": [
    {
      title: "Frontend Developer Intern",
      industry: "Software",
      location: "Cairo",
      duration: "3 months",
      salary: "3000 EGP",
      paid: true,
      skills: "HTML, CSS, JS",
      description: "Assist in building UIs.",
      company: "TechNova"
    },
    {
      title: "Graphic Design Intern",
      industry: "Design",
      location: "Remote",
      duration: "2 months",
      paid: false,
      skills: "Adobe Photoshop, Illustrator, Figma",
      description: "Support the design team in creating social media visuals, infographics, and mockups.",
      company: "TechNova"
    },
    {
      title: "Backend Developer Intern",
      industry: "Software",
      location: "Cairo",
      duration: "3 months",
      salary: "3500 EGP",
      paid: true,
      skills: "Node.js, MongoDB, Express",
      description: "Help develop and maintain backend services.",
      company: "TechNova"
    }
  ],
  "Brandly": [
    {
      title: "Social Media Intern",
      industry: "Marketing",
      location: "Cairo",
      duration: "1 month",
      salary: "1000 EGP",
      paid: true,
      skills: "Instagram, Facebook, Copywriting",
      description: "Manage daily posts and engagement for digital platforms.",
      company: "Brandly"
    },
    {
      title: "Content Marketing Intern",
      industry: "Marketing",
      location: "Remote",
      duration: "2 months",
      salary: "1500 EGP",
      paid: true,
      skills: "Content Writing, SEO, Social Media",
      description: "Create engaging content for various marketing channels.",
      company: "Brandly"
    }
  ],
  "MediScope": [
    {
      title: "Content Writer",
      industry: "Media",
      location: "Remote",
      duration: "1 month",
      paid: false,
      skills: "English Writing, SEO, WordPress",
      description: "Create and edit blog articles and landing page content.",
      company: "MediScope"
    },
    {
      title: "Video Editor Intern",
      industry: "Media",
      location: "Giza",
      duration: "2 months",
      salary: "2000 EGP",
      paid: true,
      skills: "Adobe Premiere, After Effects",
      description: "Edit and produce video content for various platforms.",
      company: "MediScope"
    }
  ]
};

let currentCompany = '';
let filteredPositions = [];

function showAvailablePositions(company) {
  currentCompany = company;
  const modal = document.getElementById('positionsModal');
  const modalTitle = document.getElementById('modalCompanyName');
  
  modalTitle.textContent = `${company} - Available Positions`;
  filteredPositions = availablePositions[company] || [];
  
  renderPositions(filteredPositions);
  modal.style.display = 'block';
}

function closePositionsModal() {
  const modal = document.getElementById('positionsModal');
  modal.style.display = 'none';
}

function filterPositions() {
  const searchTerm = document.getElementById('positionSearch').value.toLowerCase();
  const industry = document.getElementById('positionIndustryFilter').value;
  const duration = document.getElementById('positionDurationFilter').value;
  const paid = document.getElementById('positionPaidFilter').value;

  const positions = availablePositions[currentCompany] || [];
  
  filteredPositions = positions.filter(position => {
    const matchesSearch = position.title.toLowerCase().includes(searchTerm) ||
                         position.description.toLowerCase().includes(searchTerm);
    const matchesIndustry = !industry || position.industry === industry;
    const matchesDuration = !duration || position.duration === duration;
    const matchesPaid = paid === '' || String(position.paid) === paid;

    return matchesSearch && matchesIndustry && matchesDuration && matchesPaid;
  });

  renderPositions(filteredPositions);
}

function renderPositions(positions) {
  const container = document.getElementById('positionsList');
  
  if (positions.length === 0) {
    container.innerHTML = '<p class="no-positions">No positions match your criteria.</p>';
    return;
  }

  container.innerHTML = positions.map(position => `
    <div class="position-card">
      <h3>${position.title}</h3>
      <p><strong>Industry:</strong> ${position.industry}</p>
      <p><strong>Location:</strong> ${position.location}</p>
      <p><strong>Duration:</strong> ${position.duration}</p>
      <p><strong>Compensation:</strong> ${position.paid ? `Paid (${position.salary})` : 'Unpaid'}</p>
      <p><strong>Required Skills:</strong> ${position.skills}</p>
      <p>${position.description}</p>
      <button class="apply-btn" onclick="showApplicationModal('${position.title}', '${position.company}', this)">Apply Now</button>
    </div>
  `).join('');
}

function showApplicationModal(title, company, buttonElement) {
  // Create modal if it doesn't exist
  let modal = document.getElementById('applicationModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'applicationModal';
    modal.className = 'modal application-modal';
    document.body.appendChild(modal);
  }

  const position = filteredPositions.find(p => p.title === title && p.company === company);
  if (!position) return;

  modal.innerHTML = `
    <div class="modal-content application-content">
      <span class="close-btn" onclick="closeApplicationModal()">&times;</span>
      <h2>Apply for ${title}</h2>
      <h3>${company}</h3>
      
      <div class="application-details">
        <p><strong>Position:</strong> ${title}</p>
        <p><strong>Location:</strong> ${position.location}</p>
        <p><strong>Duration:</strong> ${position.duration}</p>
        <p><strong>Compensation:</strong> ${position.paid ? `Paid (${position.salary})` : 'Unpaid'}</p>
      </div>

      <div class="documents-section">
        <h4>Required Documents</h4>
        <div class="document-upload">
          <label data-required>CV/Resume (PDF)</label>
          <div class="file-input-container">
            <input type="file" class="doc-input" data-type="cv" accept=".pdf" required>
            <div class="file-input-button">Choose CV/Resume</div>
          </div>
          <span class="upload-status"></span>
        </div>
        <div class="document-upload">
          <label>Cover Letter (PDF)</label>
          <div class="file-input-container">
            <input type="file" class="doc-input" data-type="cover-letter" accept=".pdf">
            <div class="file-input-button">Choose Cover Letter</div>
          </div>
          <span class="upload-status"></span>
        </div>
        <div class="document-upload">
          <label data-required>Academic Transcript (PDF)</label>
          <div class="file-input-container">
            <input type="file" class="doc-input" data-type="transcript" accept=".pdf" required>
            <div class="file-input-button">Choose Academic Transcript</div>
          </div>
          <span class="upload-status"></span>
        </div>
      </div>
      
      <div class="modal-footer">
        <button class="cancel-btn" onclick="closeApplicationModal()">Cancel</button>
        <button class="submit-btn" onclick="submitApplication('${title}', '${company}')">Submit Application</button>
      </div>
    </div>
  `;

  // Show modal
  modal.style.display = 'block';

  // Add event listeners for file inputs
  document.querySelectorAll('.doc-input').forEach(input => {
    const button = input.nextElementSibling;
    const status = input.parentElement.nextElementSibling;
    
    input.addEventListener('change', function() {
      if (this.files.length > 0) {
        const file = this.files[0];
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
          status.textContent = '❌ File too large (max 5MB)';
          status.className = 'upload-status error';
          button.textContent = 'Choose file';
          this.value = '';
        } else {
          status.textContent = '✓ ' + file.name;
          status.className = 'upload-status success';
          button.textContent = file.name;
        }
      } else {
        status.textContent = '';
        button.textContent = 'Choose file';
      }
    });
  });
}

function closeApplicationModal() {
  const modal = document.getElementById('applicationModal');
  if (modal) {
    modal.style.display = 'none';
  }
}

function submitApplication(title, company) {
  const modal = document.getElementById('applicationModal');
  const requiredInputs = modal.querySelectorAll('.doc-input[required]');
  const allFiles = modal.querySelectorAll('.doc-input');
  
  // Check if all required documents are uploaded
  let missingRequired = false;
  requiredInputs.forEach(input => {
    if (!input.files.length) {
      missingRequired = true;
      input.parentElement.classList.add('error');
    } else {
      input.parentElement.classList.remove('error');
    }
  });

  if (missingRequired) {
    const errorMsg = modal.querySelector('.error-message') || document.createElement('div');
    errorMsg.className = 'error-message';
    errorMsg.textContent = '❌ Please upload all required documents';
    if (!modal.querySelector('.error-message')) {
      modal.querySelector('.modal-footer').insertBefore(errorMsg, modal.querySelector('.modal-footer button'));
    }
    return;
  }

  // Collect all files (in a real application, this would be sent to a server)
  const files = {};
  allFiles.forEach(input => {
    if (input.files.length) {
      files[input.dataset.type] = input.files[0];
    }
  });

  // Update the original position card
  const positionCards = document.querySelectorAll('.position-card');
  positionCards.forEach(card => {
    if (card.querySelector('h3').textContent === title) {
      const applyBtn = card.querySelector('.apply-btn');
      applyBtn.disabled = true;
      applyBtn.textContent = 'Applied';
      applyBtn.style.backgroundColor = '#6c757d';
      
      const successMsg = document.createElement('div');
      successMsg.className = 'success-message';
      successMsg.textContent = '✅ Application submitted successfully!';
      card.appendChild(successMsg);
    }
  });

  // Close the modal
  closeApplicationModal();
}

// Close modal when clicking outside
window.addEventListener('click', (e) => {
  const modal = document.getElementById('applicationModal');
  if (e.target === modal) {
    closeApplicationModal();
  }
}); 