const dummyCvUrl = "../../assets/dummy-cv.pdf";

// Initial dummy data
const initialApplications = [
  {
    name: "Ahmed Hassan",
    email: "ahmed.hassan@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "pending",
    skills: "HTML, CSS, React, JavaScript, TypeScript",
    resume: dummyCvUrl,
    description: "Third-year computer science student with experience in web development and UI/UX design. Looking to apply my frontend development skills in a professional environment."
  },
  {
    name: "Mariam Adel",
    email: "mariam.adel@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "finalized",
    skills: "Adobe Photoshop, Illustrator, Figma, UI Design",
    resume: dummyCvUrl,
    description: "Creative design student with a strong portfolio in branding and digital media. Passionate about creating visually appealing and user-friendly designs."
  },
  {
    name: "Omar Khaled",
    email: "omar.khaled@student.guc.edu.eg",
    post: "Network Engineer Intern",
    status: "pending",
    skills: "Cisco, Networking, Wireshark, Network Security",
    resume: dummyCvUrl,
    description: "Final year student specializing in network infrastructure and security. Cisco certified with hands-on experience in network troubleshooting."
  },
  {
    name: "Sarah Mohamed",
    email: "sarah.mohamed@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "finalized",
    skills: "React, Vue.js, Bootstrap, SASS, Responsive Design",
    resume: dummyCvUrl,
    description: "Passionate about creating intuitive user interfaces. Experience with modern frontend frameworks and responsive design principles."
  },
  {
    name: "Youssef Ibrahim",
    email: "youssef.ibrahim@student.guc.edu.eg",
    post: "Network Engineer Intern",
    status: "pending",
    skills: "Network Administration, Linux, Cloud Computing",
    resume: dummyCvUrl,
    description: "Strong foundation in network administration and cloud technologies. Eager to gain hands-on experience in enterprise networking."
  },
  {
    name: "Nour Ahmed",
    email: "nour.ahmed@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "pending",
    skills: "Adobe Creative Suite, Motion Graphics, Web Design",
    resume: dummyCvUrl,
    description: "Combining artistic vision with technical skills. Experienced in creating engaging visual content for digital platforms."
  },
  {
    name: "Karim Mostafa",
    email: "karim.mostafa@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "finalized",
    skills: "JavaScript, Angular, Node.js, MongoDB",
    resume: dummyCvUrl,
    description: "Full-stack capable with a focus on frontend development. Passionate about creating seamless user experiences."
  },
  {
    name: "Yasmine Ali",
    email: "yasmine.ali@student.guc.edu.eg",
    post: "Network Engineer Intern",
    status: "finalized",
    skills: "Network Security, Firewall Configuration, VPN",
    resume: dummyCvUrl,
    description: "Focused on network security and infrastructure protection. Experience with various security tools and protocols."
  },
  {
    name: "Mohamed Saad",
    email: "mohamed.saad@student.guc.edu.eg",
    post: "Graphic Design Intern",
    status: "pending",
    skills: "Brand Design, Typography, Digital Marketing",
    resume: dummyCvUrl,
    description: "Creative designer with marketing insight. Experienced in creating cohesive brand identities and marketing materials."
  },
  {
    name: "Rana Hossam",
    email: "rana.hossam@student.guc.edu.eg",
    post: "Frontend Developer Intern",
    status: "pending",
    skills: "React Native, Mobile Development, UI Design",
    resume: dummyCvUrl,
    description: "Specialized in mobile-first development with React Native. Strong understanding of UI/UX principles."
  }
];

// Function to reset data to initial state (only call this manually if needed)
function resetApplicationsData() {
  localStorage.setItem("applications", JSON.stringify(initialApplications));
  localStorage.removeItem("expandedApplications");
  applications = [...initialApplications];
  filteredApps = [...initialApplications];
  renderApplications();
}

// Load from localStorage or use initial data
let applications = JSON.parse(localStorage.getItem("applications"));
// Initialize data only if it's the first time (applications is null)
if (!applications) {
  applications = [...initialApplications];
  localStorage.setItem("applications", JSON.stringify(applications));
}
let filteredApps = [...applications];

function navigateTo(page) {
  // Save current state before navigation
  localStorage.setItem("applications", JSON.stringify(applications));
  window.location.href = `../company/${page}.html`;
}

function filterApplications() {
  const filter = document.getElementById("filterPost").value;
  filteredApps = !filter
    ? [...applications]
    : applications.filter(app => app.post === filter);
  renderApplications();
  updateKPIs();
}

function updateKPIs() {
  // Get all applications (including those that were accepted/rejected)
  const allApplications = JSON.parse(localStorage.getItem("applications")) || [];
  const acceptedInterns = JSON.parse(localStorage.getItem("interns")) || [];
  const rejectedApplications = JSON.parse(localStorage.getItem("rejectedApplications")) || [];

  // Calculate statistics
  const total = allApplications.length + acceptedInterns.length + rejectedApplications.length;
  const pending = allApplications.filter(app => app.status === "pending").length;
  const finalized = allApplications.filter(app => app.status === "finalized").length;
  const accepted = acceptedInterns.length;
  const rejected = rejectedApplications.length;

  // Update the KPI displays
  document.getElementById("totalApplications").textContent = total;
  document.getElementById("pendingApplications").textContent = pending;
  document.getElementById("finalizedApplications").textContent = finalized;
  document.getElementById("acceptedApplications").textContent = accepted;
  document.getElementById("rejectedApplications").textContent = rejected;
}

function updateStatus(index, status) {
  const app = filteredApps[index];
  
  switch(status) {
    case 'rejected':
      // Store rejected application before removing
      const rejectedApplications = JSON.parse(localStorage.getItem("rejectedApplications")) || [];
      rejectedApplications.push({...app, status: 'rejected'});
      localStorage.setItem("rejectedApplications", JSON.stringify(rejectedApplications));
      
      // Add notification for rejected application
      addNotification('applications', {
        title: "Application Rejected",
        details: `An application has been rejected:

Position: ${app.post}
Applicant: ${app.name}
Student ID: ${app.email.split('@')[0]}

The applicant will be notified of this decision.`,
        type: "application_status",
        link: "./applications.html"
      });
      
      // Remove from applications array
      const rejectIndex = applications.findIndex(a => a.email === app.email);
      applications.splice(rejectIndex, 1);
      
      // Remove from filtered apps
      filteredApps.splice(index, 1);
      break;
      
    case 'accepted':
      // Move to interns
      const interns = JSON.parse(localStorage.getItem("interns")) || [];
      interns.push({
        name: app.name,
        email: app.email,
        position: app.post,
        skills: app.skills,
        startDate: new Date().toISOString(),
        status: "current intern"
      });
      localStorage.setItem("interns", JSON.stringify(interns));
      
      // Add notification for accepted application
      addNotification('applications', {
        title: "Application Accepted",
        details: `An application has been accepted:

Position: ${app.post}
Applicant: ${app.name}
Student ID: ${app.email.split('@')[0]}

The applicant has been moved to the interns list.`,
        type: "application_status",
        link: "./interns.html"
      });
      
      // Remove from applications
      const acceptIndex = applications.findIndex(a => a.email === app.email);
      applications.splice(acceptIndex, 1);
      
      // Remove from filtered apps
      filteredApps.splice(index, 1);
      break;
      
    case 'finalized':
      // Just update the status without removing
      app.status = "finalized";
      const finalizeIndex = applications.findIndex(a => a.email === app.email);
      applications[finalizeIndex] = { ...app };

      // Add notification for finalized application
      addNotification('applications', {
        title: "Application Finalized",
        details: `An application has been finalized:

Position: ${app.post}
Applicant: ${app.name}
Student ID: ${app.email.split('@')[0]}

The application process is now complete.`,
        type: "application_status",
        link: "./applications.html"
      });
      break;
  }

  // Save updated applications to localStorage
  localStorage.setItem("applications", JSON.stringify(applications));
  
  // Update KPIs
  updateKPIs();
  
  // Re-render the applications list
  renderApplications();
}

function toggleApplicationDetails(event, index) {
  event.stopPropagation();
  
  const applicationCard = event.target.closest('.post-card');
  applicationCard.classList.toggle('expanded');
  
  // Update button text
  const button = event.target;
  button.textContent = applicationCard.classList.contains('expanded') ? 'Hide Details' : 'View Details';

  // Save expanded state to localStorage
  const expandedApplications = JSON.parse(localStorage.getItem('expandedApplications') || '[]');
  if (applicationCard.classList.contains('expanded')) {
    if (!expandedApplications.includes(index)) {
      expandedApplications.push(index);
    }
  } else {
    const idx = expandedApplications.indexOf(index);
    if (idx > -1) {
      expandedApplications.splice(idx, 1);
    }
  }
  localStorage.setItem('expandedApplications', JSON.stringify(expandedApplications));
}

function renderApplications() {
  const container = document.getElementById("applicationsContainer");
  container.innerHTML = "";

  if (filteredApps.length === 0) {
    container.innerHTML = "<p>No applications found.</p>";
    return;
  }

  // Get expanded applications from localStorage
  const expandedApplications = JSON.parse(localStorage.getItem('expandedApplications') || '[]');

  filteredApps.forEach((app, idx) => {
    const div = document.createElement("div");
    div.className = "post-card";
    if (expandedApplications.includes(idx)) {
      div.classList.add('expanded');
    }
    div.setAttribute('data-application-id', idx);
    
    div.innerHTML = `
      <div class="post-header">
        <div class="header-info">
      <h3>${app.name}</h3>
      <p><strong>Applied for:</strong> ${app.post}</p>
      <p><strong>Status:</strong> <span class="badge ${app.status.replaceAll(" ", "-")}">${app.status}</span></p>
        </div>
        <div class="post-actions">
          <button onclick="toggleApplicationDetails(event, ${idx})" class="btn-action btn-view-red">
            ${expandedApplications.includes(idx) ? 'Hide Details' : 'View Details'}
          </button>
        </div>
      </div>
      <div class="post-details">
        <p><strong>Email:</strong> ${app.email}</p>
      <p><strong>Skills:</strong> ${app.skills}</p>
      <p><strong>Description:</strong> ${app.description}</p>
      <p><strong>Resume:</strong> <a href="${app.resume}" target="_blank">View CV</a></p>
      <div class="status-buttons">
        <button class="green" onclick="updateStatus(${idx}, 'accepted')">Accept</button>
        <button class="red" onclick="updateStatus(${idx}, 'rejected')">Reject</button>
        <button class="grey" onclick="updateStatus(${idx}, 'finalized')">Finalize</button>
        </div>
      </div>
    `;
    container.appendChild(div);
  });
}

// Update the DOMContentLoaded event handler
document.addEventListener("DOMContentLoaded", () => {
  // Update the filter dropdown with current posts
  updateFilterOptions();
  renderApplications();
  updateKPIs();
  
  // Add beforeunload event listener to save state before leaving page
  window.addEventListener('beforeunload', () => {
    localStorage.setItem("applications", JSON.stringify(applications));
  });
});

// Function to update filter options based on available posts
function updateFilterOptions() {
  const filterSelect = document.getElementById("filterPost");
  if (!filterSelect) return;

  // Get unique posts
  const uniquePosts = [...new Set(applications.map(app => app.post))];
  
  // Clear existing options except the first one
  filterSelect.innerHTML = '<option value="">Filter by Internship</option>';
  
  // Add options for each unique post
  uniquePosts.forEach(post => {
    const option = document.createElement("option");
    option.value = post;
    option.textContent = post;
    filterSelect.appendChild(option);
  });
}