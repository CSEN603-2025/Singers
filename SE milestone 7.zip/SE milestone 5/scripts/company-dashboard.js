let posts = JSON.parse(localStorage.getItem("posts")) || [
  {
    id: Date.now(), // Ensure first post has a unique ID
    title: "Frontend Developer Intern",
    industry: "Software",
    location: "Cairo",
    duration: "3 months",
    salary: "3000 EGP",
    paid: true,
    skills: "HTML, CSS, JS",
    description: "Assist in building UIs.",
    company: "TechNova"
  }
];

function navigateTo(page) {
  // Remove active class from all buttons
  document.querySelectorAll('.nav-button').forEach(btn => {
    btn.classList.remove('active');
  });

  // Add active class to the clicked button
  const clickedButton = document.querySelector(`.nav-button[onclick*="navigateTo('${page}')"]`);
  if (clickedButton) {
    clickedButton.classList.add('active');
  }

  // Navigate to the appropriate page
  if (page === 'dashboard') {
    window.location.href = 'dashboard.html';
  } else {
    window.location.href = `${page}.html`;
  }
}

function toggleAddForm() {
  document.getElementById("addForm").classList.toggle("hidden");
}

function toggleFilter() {
  document.getElementById("filterForm").classList.toggle("hidden");
}

function addPost(e) {
  e.preventDefault();
  const post = {
    id: Date.now(), // Add unique ID for each post
    title: document.getElementById("title").value,
    industry: document.getElementById("industry").value,
    location: document.getElementById("location").value,
    duration: document.getElementById("duration").value,
    salary: document.getElementById("salary").value,
    paid: document.getElementById("paid").value === "true",
    skills: document.getElementById("skills").value,
    description: document.getElementById("description").value,
    company: "TechNova"
  };
  posts.unshift(post);
localStorage.setItem("posts", JSON.stringify(posts));
  
  // Add notification for new internship post
  addNotification('internships', {
    title: "New Internship Posted",
    details: `A new internship position has been posted:

Position: ${post.title}
Industry: ${post.industry}
Location: ${post.location}
Duration: ${post.duration}
${post.paid ? `Salary: ${post.salary}` : 'Unpaid'}

The position is now open for applications.`,
    type: "internship_update",
    link: "./dashboard.html"
  });
  
renderPosts(posts);
  document.getElementById("addForm").reset();
  toggleAddForm();
}

function deletePost(id) {
  if (confirm("Are you sure you want to delete this internship post?")) {
    // Find the post
    const post = posts.find(p => p.id === id);
    if (post) {
      // Find the post index
      const postIndex = posts.findIndex(p => p.id === id);
      if (postIndex !== -1) {
        // Remove the post
        posts.splice(postIndex, 1);
        localStorage.setItem("posts", JSON.stringify(posts));
        
        // Add notification for deleted internship
        addNotification('internships', {
          title: "Internship Position Removed",
          details: `The following internship position has been removed:

Position: ${post.title}
Industry: ${post.industry}
Location: ${post.location}

This position is no longer accepting applications.`,
          type: "internship_update"
        });
        
        // Remove from expanded posts if it was expanded
        const expandedPosts = JSON.parse(localStorage.getItem('expandedPosts') || '[]');
        const expandedIndex = expandedPosts.indexOf(id);
        if (expandedIndex > -1) {
          expandedPosts.splice(expandedIndex, 1);
          localStorage.setItem('expandedPosts', JSON.stringify(expandedPosts));
        }
        
        renderPosts(posts);
      }
    }
  }
}

function openEditModal(id) {
  const post = posts.find(p => p.id === id);
  if (!post) return;

  // Fill the edit form with post data
  document.getElementById("editId").value = post.id;
  document.getElementById("editTitle").value = post.title;
  document.getElementById("editIndustry").value = post.industry;
  document.getElementById("editLocation").value = post.location;
  document.getElementById("editDuration").value = post.duration;
  document.getElementById("editSalary").value = post.salary;
  document.getElementById("editPaid").value = post.paid.toString();
  document.getElementById("editSkills").value = post.skills;
  document.getElementById("editDescription").value = post.description;

  // Show the modal
  document.getElementById("editModal").classList.remove("hidden");
}

function closeEditModal() {
  document.getElementById("editModal").classList.add("hidden");
}

function updatePost(e) {
  e.preventDefault();
  const id = parseInt(document.getElementById("editId").value);
  const updatedPost = {
    id: id,
    title: document.getElementById("editTitle").value,
    industry: document.getElementById("editIndustry").value,
    location: document.getElementById("editLocation").value,
    duration: document.getElementById("editDuration").value,
    salary: document.getElementById("editSalary").value,
    paid: document.getElementById("editPaid").value === "true",
    skills: document.getElementById("editSkills").value,
    description: document.getElementById("editDescription").value,
    company: "TechNova"
  };

  // Find the old post for comparison
  const oldPost = posts.find(p => p.id === id);
  
  // Update the post in the array
  posts = posts.map(p => p.id === id ? updatedPost : p);
  
  // Save to localStorage
  localStorage.setItem("posts", JSON.stringify(posts));
  
  // Add notification for updated internship
  if (oldPost) {
    const changes = [];
    if (oldPost.title !== updatedPost.title) changes.push('Title');
    if (oldPost.industry !== updatedPost.industry) changes.push('Industry');
    if (oldPost.location !== updatedPost.location) changes.push('Location');
    if (oldPost.duration !== updatedPost.duration) changes.push('Duration');
    if (oldPost.salary !== updatedPost.salary) changes.push('Salary');
    if (oldPost.paid !== updatedPost.paid) changes.push('Payment Status');
    if (oldPost.skills !== updatedPost.skills) changes.push('Required Skills');
    if (oldPost.description !== updatedPost.description) changes.push('Description');
    
    if (changes.length > 0) {
      addNotification('internships', {
        title: "Internship Position Updated",
        details: `Changes have been made to the internship position:

Position: ${updatedPost.title}
Updated Fields: ${changes.join(', ')}

Please review the changes in the internship details.`,
        type: "internship_update",
        link: "./dashboard.html"
      });
    }
  }
  
  // Get current expanded state before re-rendering
  const expandedPosts = JSON.parse(localStorage.getItem('expandedPosts') || '[]');
  
  // Close the modal
  closeEditModal();
  
  // Re-render with expanded state preserved
  renderPosts(posts);
  
  // If the post was expanded, scroll to it
  if (expandedPosts.includes(id)) {
    const updatedPostElement = document.querySelector(`[data-post-id="${id}"]`);
    if (updatedPostElement) {
      updatedPostElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
}

function clearFilters() {
  // Reset all filter inputs
  document.getElementById("filterIndustry").value = "";
  document.getElementById("filterDuration").value = "";
  document.getElementById("filterPaid").value = "";
  
  // Re-render all posts
  renderPosts(posts);
}

function filterPosts(e) {
  e.preventDefault();
  const industry = document.getElementById("filterIndustry").value;
  const duration = document.getElementById("filterDuration").value;
  const paid = document.getElementById("filterPaid").value;

  const filtered = posts.filter(p =>
    (industry === "" || p.industry === industry) &&
    (duration === "" || p.duration === duration) &&
    (paid === "" || String(p.paid) === paid)
  );

  renderPosts(filtered);
}

function togglePostDetails(event, postId) {
  event.stopPropagation();
  
  const postCard = event.target.closest('.post-card');
  postCard.classList.toggle('expanded');
  
  // Update button text
  const button = event.target;
  button.textContent = postCard.classList.contains('expanded') ? 'Hide Details' : 'View Details';

  // Save expanded state to localStorage
  const expandedPosts = JSON.parse(localStorage.getItem('expandedPosts') || '[]');
  if (postCard.classList.contains('expanded')) {
    if (!expandedPosts.includes(postId)) {
      expandedPosts.push(postId);
    }
  } else {
    const index = expandedPosts.indexOf(postId);
    if (index > -1) {
      expandedPosts.splice(index, 1);
    }
  }
  localStorage.setItem('expandedPosts', JSON.stringify(expandedPosts));
}

function getApplicationCount(postTitle) {
  const applications = JSON.parse(localStorage.getItem("applications")) || [];
  return applications.filter(app => app.post === postTitle).length;
}

function renderPosts(data) {
  const container = document.getElementById("postsContainer");
  container.innerHTML = "";

  if (data.length === 0) {
    container.innerHTML = "<p>No internships available.</p>";
    return;
  }

  // Get expanded posts from localStorage
  const expandedPosts = JSON.parse(localStorage.getItem('expandedPosts') || '[]');

  data.forEach(p => {
    const applicationCount = getApplicationCount(p.title);
    const div = document.createElement("div");
    div.className = "post-card";
    if (expandedPosts.includes(p.id)) {
      div.classList.add('expanded');
    }
    div.setAttribute('data-post-id', p.id);
    
    div.innerHTML = `
      <div class="post-header">
        <div class="header-info">
      <h3>${p.title}</h3>
          <div class="post-meta">
            <span class="application-count">
              <strong>Applications:</strong> ${applicationCount}
            </span>
            <span class="post-status">
              <strong>Status:</strong> ${p.paid ? `Paid (${p.salary})` : 'Unpaid'}
            </span>
          </div>
        </div>
        <div class="post-actions">
          <button onclick="togglePostDetails(event, ${p.id})" class="btn-action btn-view">
            ${expandedPosts.includes(p.id) ? 'Hide Details' : 'View Details'}
          </button>
          <button onclick="openEditModal(${p.id})" class="btn-action btn-edit">Edit</button>
          <button onclick="deletePost(${p.id})" class="btn-action btn-delete">Delete</button>
        </div>
      </div>
      <div class="post-details">
      <p><strong>Industry:</strong> ${p.industry}</p>
      <p><strong>Location:</strong> ${p.location}</p>
      <p><strong>Duration:</strong> ${p.duration}</p>
        <p><strong>Skills Required:</strong> ${p.skills}</p>
        <p><strong>Description:</strong></p>
        <p class="description">${p.description}</p>
      </div>
    `;
    
    container.appendChild(div);
  });
}

function toggleNotifications() {
  const panel = document.getElementById("notifPanel");
  panel.classList.toggle("hidden");

  document.getElementById("notifCount").classList.add("hidden");
  localStorage.setItem("notificationsRead", "true");
}

function loadNotifications() {
  const list = document.getElementById("notifList");
  const notifs = JSON.parse(localStorage.getItem("notifications")) || [];

 list.innerHTML = "";
notifs.slice().reverse().forEach((n, i) => {
  const li = document.createElement("li");
  li.innerText = n.message;
  li.classList.add("clickable-notif");
  li.onclick = () => handleNotificationClick(n.message);
  list.appendChild(li);
});

function handleNotificationClick(message) {
  document.getElementById("notifModalMessage").innerText = message;
  document.getElementById("notifModal").classList.remove("hidden");
}

function closeNotifModal() {
  document.getElementById("notifModal").classList.add("hidden");
}

  const unread = localStorage.getItem("notificationsRead") !== "true";
  if (notifs.length > 0 && unread) {
    const badge = document.getElementById("notifCount");
    badge.innerText = notifs.length;
    badge.classList.remove("hidden");
  }
}

function addNotification(message) {
  const notifs = JSON.parse(localStorage.getItem("notifications")) || [];
  notifs.push({ message, timestamp: Date.now() });
  localStorage.setItem("notifications", JSON.stringify(notifs));
  localStorage.setItem("notificationsRead", "false");
  loadNotifications();
}

// Dummy data to start
posts = [
  {
    title: "Frontend Developer Intern",
    industry: "Software",
    location: "Cairo",
    duration: "3 months",
    salary: "3000 EGP",
    paid: true,
    skills: "HTML, CSS, JS",
    description: "Assist in building UIs.",
    company: "TechNova"
  },
  {
    title: "Graphic Design Intern",
    industry: "Design",
    location: "Remote",
    duration: "2 months",
    salary: "Unpaid",
    paid: false,
    skills: "Adobe Photoshop, Illustrator, Figma",
    description: "Support the design team in creating social media visuals, infographics, and mockups.",
    company: "TechNova"
  },
  {
    title: "Social Media Intern",
    industry: "Marketing",
    location: "Cairo",
    duration: "1 month",
    salary: "1000 EGP",
    paid: true,
    skills: "Instagram, Facebook, Copywriting",
    description: "Manage daily posts and engagement for TechNova's digital platforms.",
    company: "TechNova"
  },
  {
    title: "Quality Assurance Intern",
    industry: "Software Testing",
    location: "Giza",
    duration: "3 months",
    salary: "2500 EGP",
    paid: true,
    skills: "Manual Testing, TestRail, Jira",
    description: "Test features, log bugs, and collaborate with developers to ensure a high-quality product.",
    company: "TechNova"
  },
  {
    title: "Content Writer Intern",
    industry: "Media",
    location: "Remote",
    duration: "1 month",
    salary: "Unpaid",
    paid: false,
    skills: "English Writing, SEO, WordPress",
    description: "Create and edit blog articles and landing page content to support marketing goals.",
    company: "TechNova"
  },
  {
    title: "Network Engineer Intern",
    industry: "IT",
    location: "Cairo",
    duration: "3 months",
    salary: "3500 EGP",
    paid: true,
    skills: "Cisco, Networking, Wireshark",
    description: "Assist with infrastructure maintenance and resolve connectivity issues across offices.",
    company: "TechNova"
  },
  {
    title: "Project Coordinator Intern",
    industry: "Business",
    location: "Hybrid",
    duration: "2 months",
    salary: "1500 EGP",
    paid: true,
    skills: "Planning, Communication, Excel",
    description: "Help coordinate tasks, schedules, and reporting with project stakeholders.",
    company: "TechNova"
  }
];

addNotification("📥 A student applied to your internship!");
addNotification("✅ SCAD has approved your company.");
document.addEventListener("DOMContentLoaded", () => {
  // Load posts from localStorage or use default data
  posts = JSON.parse(localStorage.getItem("posts")) || posts;
  renderPosts(posts);
});