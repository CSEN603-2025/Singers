// Function to load the header into any page that includes this script
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/components/header.html');
        const headerHtml = await response.text();
        document.body.insertAdjacentHTML('afterbegin', headerHtml);
    } catch (error) {
        console.error('Error loading header:', error);
    }
});

// Handle logout functionality
function handleLogout() {
    // Clear any stored authentication
    localStorage.removeItem('authToken');
    sessionStorage.clear();
    
    // Redirect to login page
    window.location.href = '/main.html';
} 