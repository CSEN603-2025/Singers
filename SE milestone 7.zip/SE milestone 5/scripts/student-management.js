// Dummy student data
const students = [
    {
        id: "49-12345",
        name: "Ahmed Mohamed",
        major: "Computer Science",
        gpa: 3.8,
        level: "Senior",
        status: "in_progress",
        company: "TechCorp Solutions",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        supervisor: "John Smith"
    },
    {
        id: "49-12346",
        name: "Sarah Ahmed",
        major: "Computer Engineering",
        gpa: 3.9,
        level: "Senior",
        status: "not_started",
        company: "Pending",
        startDate: "-",
        endDate: "-",
        supervisor: "-"
    },
    {
        id: "49-12347",
        name: "Omar Hassan",
        major: "Computer Science",
        gpa: 3.7,
        level: "Senior",
        status: "completed",
        company: "FinanceHub",
        startDate: "2023-09-01",
        endDate: "2024-03-01",
        supervisor: "Mary Johnson"
    },
    {
        id: "49-12348",
        name: "Fatima Ali",
        major: "Computer Engineering",
        gpa: 3.6,
        level: "Senior",
        status: "in_progress",
        company: "HealthCare Plus",
        startDate: "2024-02-01",
        endDate: "2024-08-01",
        supervisor: "David Wilson"
    },
    {
        id: "49-12349",
        name: "Youssef Ibrahim",
        major: "Computer Science",
        gpa: 3.5,
        level: "Senior",
        status: "not_started",
        company: "Pending",
        startDate: "-",
        endDate: "-",
        supervisor: "-"
    }
];

// DOM Elements
const studentsGrid = document.getElementById('studentsGrid');
const searchInput = document.getElementById('studentSearch');
const statusFilter = document.getElementById('statusFilter');

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    renderStudents(students);
    setupEventListeners();
});

// Event Listeners
function setupEventListeners() {
    searchInput.addEventListener('input', filterStudents);
    statusFilter.addEventListener('change', filterStudents);
}

// Render students grid
function renderStudents(studentsToRender) {
    studentsGrid.innerHTML = studentsToRender.map(student => `
        <div class="student-card">
            <div class="student-card-header" onclick="toggleStudentDetails('${student.id}')">
            <h3>${student.name}</h3>
                <p>ID: ${student.id}</p>
                <p>Major: ${student.major}</p>
                <p>Company: ${student.company}</p>
                <span class="status-badge status-${student.status}">${formatStatus(student.status)}</span>
                <span class="expand-icon">▼</span>
        </div>
            <div class="student-details" id="details-${student.id}">
                <div class="details-content">
                    <h4>Personal Information</h4>
                    <p><strong>Level:</strong> ${student.level}</p>
                    <p><strong>GPA:</strong> ${student.gpa}</p>
                    
                    <h4>Internship Details</h4>
                    <p><strong>Start Date:</strong> ${student.startDate}</p>
                    <p><strong>End Date:</strong> ${student.endDate}</p>
                    <p><strong>Supervisor:</strong> ${student.supervisor}</p>
                </div>
            </div>
        </div>
    `).join('');
}

// Filter students
function filterStudents() {
    const searchTerm = searchInput.value.toLowerCase();
    const statusValue = statusFilter.value;

    const filtered = students.filter(student => {
        const matchesSearch = student.name.toLowerCase().includes(searchTerm) ||
                            student.id.toLowerCase().includes(searchTerm) ||
                            student.major.toLowerCase().includes(searchTerm);
        const matchesStatus = statusValue === 'all' || student.status === statusValue;
        return matchesSearch && matchesStatus;
    });

    renderStudents(filtered);
}

// Toggle student details
function toggleStudentDetails(studentId) {
    const detailsSection = document.getElementById(`details-${studentId}`);
    const card = detailsSection.closest('.student-card');
    const expandIcon = card.querySelector('.expand-icon');
    
    if (detailsSection.style.maxHeight) {
        detailsSection.style.maxHeight = null;
        expandIcon.style.transform = 'rotate(0deg)';
        card.classList.remove('expanded');
    } else {
        detailsSection.style.maxHeight = detailsSection.scrollHeight + "px";
        expandIcon.style.transform = 'rotate(180deg)';
        card.classList.add('expanded');
        
        // Scroll the card into view if it's not fully visible
        const cardRect = card.getBoundingClientRect();
        const isFullyVisible = (cardRect.top >= 0) && (cardRect.bottom <= window.innerHeight);
        
        if (!isFullyVisible) {
            card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
}

// Helper function to format status
function formatStatus(status) {
    return status.split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

// Initialize the page
filterStudents(); 