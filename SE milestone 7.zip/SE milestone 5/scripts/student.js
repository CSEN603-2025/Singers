
function apply() {
  alert("Application submitted!");
}

function submitReport() {
  alert("Report uploaded successfully.");

  document.addEventListener('DOMContentLoaded', function () {
  const userType = localStorage.getItem('userType');

  if (userType === 'pro') {
    document.getElementById('proFeatures').style.display = 'block';
  }
});

function apply() {
  alert("Application submitted!");
}

function submitReport() {
  alert("Report uploaded successfully.");
}
}
