// Dummy data for internship cycles
const internshipCycles = [
    {
        id: 1,
        title: "Summer Internship Cycle 2024",
        startDate: "2024-06-01",
        endDate: "2024-08-31",
        status: "upcoming",
        totalStudents: 150,
        companiesParticipating: 45
    },
    {
        id: 2,
        title: "Winter Internship Cycle 2024",
        startDate: "2024-01-15",
        endDate: "2024-03-15",
        status: "active",
        totalStudents: 120,
        companiesParticipating: 38
    },
    {
        id: 3,
        title: "Fall Internship Cycle 2023",
        startDate: "2023-09-01",
        endDate: "2023-11-30",
        status: "completed",
        totalStudents: 135,
        companiesParticipating: 42
    }
];

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    displayInternshipCycles();
});

// Display internship cycles
function displayInternshipCycles() {
    const cyclesGrid = document.getElementById('cyclesGrid');
    cyclesGrid.innerHTML = '';

    internshipCycles.forEach(cycle => {
        const startDate = new Date(cycle.startDate).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const endDate = new Date(cycle.endDate).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        const cycleCard = document.createElement('div');
        cycleCard.className = 'cycle-card';
        cycleCard.innerHTML = `
            <h3>${cycle.title}</h3>
            <div class="cycle-info">
                <p>${cycle.totalStudents} Students Enrolled</p>
                <p>${cycle.companiesParticipating} Companies Participating</p>
            </div>
            <div class="cycle-dates">
                <div class="cycle-date">
                    <span>Start Date</span>
                    <span>${startDate}</span>
                </div>
                <div class="cycle-date">
                    <span>End Date</span>
                    <span>${endDate}</span>
                </div>
            </div>
            <span class="cycle-status status-${cycle.status}">
                ${cycle.status.charAt(0).toUpperCase() + cycle.status.slice(1)}
            </span>
        `;

        cyclesGrid.appendChild(cycleCard);
    });
}

// Modal functions
function openAddCycleModal() {
    document.getElementById('addCycleModal').style.display = 'flex';
}

function closeAddCycleModal() {
    document.getElementById('addCycleModal').style.display = 'none';
    document.getElementById('addCycleForm').reset();
}

// Handle form submission
function handleAddCycle(event) {
    event.preventDefault();

    const title = document.getElementById('cycleTitle').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;

    // Create new cycle object
    const newCycle = {
        id: internshipCycles.length + 1,
        title: title,
        startDate: startDate,
        endDate: endDate,
        status: 'upcoming',
        totalStudents: 0,
        companiesParticipating: 0
    };

    // Add to cycles array
    internshipCycles.unshift(newCycle);

    // Refresh display
    displayInternshipCycles();

    // Close modal
    closeAddCycleModal();
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('addCycleModal');
    if (event.target == modal) {
        closeAddCycleModal();
    }
} 