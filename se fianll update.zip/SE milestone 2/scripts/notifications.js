// Dummy notifications data structure
const INITIAL_NOTIFICATIONS = [
  {
    id: Date.now() - 1000,
    title: "New Internship Application",
    details: `A new application has been received:
    
Position: Software Engineering Intern
Applicant: Ahmed Hassan
Student ID: 231047
Major: Computer Science & Engineering
GPA: 3.8

The applicant's resume and portfolio are available for review.`,
    date: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    type: "new_application",
    read: false,
    link: "../company/applications.html"
  },
  {
    id: Date.now() - 2000,
    title: "Company Registration Accepted",
    details: `Your company registration for TechCorp Solutions has been approved by SCAD.

You now have full access to:
- Post internship opportunities
- Review student applications
- Manage interns
- Generate reports

Welcome to the GUC Internship Portal!`,
    date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    type: "registration_accepted",
    read: true
  },
  {
    id: Date.now() - 3000,
    title: "Company Registration Rejected",
    details: `Your company registration for DataTech Inc. has been rejected by SCAD.

Reason: Insufficient company documentation provided.

Please submit a new registration with:
- Valid commercial registration
- Updated company profile
- Complete contact information`,
    date: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    type: "registration_rejected",
    read: false
  },
  {
    id: Date.now() - 4000,
    title: "New Internship Application",
    details: `A new application has been received:
    
Position: Marketing Intern
Applicant: Sara Ahmed
Student ID: 231089
Major: Business Administration
GPA: 3.6

The applicant's resume and portfolio are available for review.`,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    type: "new_application",
    read: true,
    link: "../company/applications.html"
  }
];

// Initialize notifications array
let notifications = [];

// Format relative time
function formatRelativeTime(dateString) {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (isNaN(diffInSeconds)) return 'Just now';
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) {
      const mins = Math.floor(diffInSeconds / 60);
      return `${mins}m ago`;
    }
    if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours}h ago`;
    }
    if (diffInSeconds < 604800) {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days}d ago`;
    }
    
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  } catch (e) {
    console.error('Date formatting error:', e);
    return 'Recent';
  }
}

// Save notifications to localStorage
function saveNotifications() {
  localStorage.setItem('notifications', JSON.stringify(notifications));
}

// Load notifications from localStorage or initialize with dummy data
function loadNotifications() {
  const stored = localStorage.getItem('notifications');
  if (stored) {
    notifications = JSON.parse(stored);
  } else {
    notifications = INITIAL_NOTIFICATIONS;
    saveNotifications();
  }
  updateNotificationsUI();
}

// Add new notification
function addNotification(notification) {
  const newNotification = {
    id: Date.now(),
    date: new Date().toISOString(),
    read: false,
    ...notification
  };

  notifications.unshift(newNotification);
  updateNotificationsUI();
  saveNotifications();
  
  // Mock email notification
  console.log('Email notification sent:', newNotification);
}

// Mark notification as read
function markAsRead(id) {
  const notification = notifications.find(n => n.id === id);
  if (notification) {
    notification.read = true;
    updateNotificationsUI();
    saveNotifications();
  }
}

// Get unread count
function getUnreadCount() {
  return notifications.filter(n => !n.read).length;
}

// Show notification details modal
function showNotificationDetails(id) {
  const notification = notifications.find(n => n.id === id);
  if (!notification) return;

  markAsRead(id);

  const modal = document.createElement('div');
  modal.className = 'modal notification-modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="notification-header">
        <h3>${notification.title}</h3>
        <span class="notification-date">${formatRelativeTime(notification.date)}</span>
      </div>
      <div class="notification-body">
        <p>${notification.details}</p>
      </div>
            <div class="modal-actions">        ${notification.link ?           `<div class="button-group">            <button class="btn-primary" onclick="window.location.href='${notification.link}'">View Details</button>            <button class="btn-secondary" onclick="closeNotificationModal()">Close</button>          </div>`           : '<button class="btn-secondary" onclick="closeNotificationModal()">Close</button>'}      </div>
    </div>
  `;
  
  const container = document.getElementById('notificationModalContainer');
  if (container) {
    container.innerHTML = '';
    container.appendChild(modal);
  } else {
    document.body.appendChild(modal);
  }
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.querySelector('.notification-modal');
  if (modal) {
    modal.remove();
  }
}

// Update notifications UI
function updateNotificationsUI() {
  const notifCount = document.getElementById('notifCount');
  const notifList = document.getElementById('notifList');
  const unreadCount = getUnreadCount();
  
  if (!notifList) {
    console.error('Notification list element not found');
    return;
  }

  // Update badge
  if (notifCount) {
    notifCount.textContent = unreadCount;
    notifCount.classList.toggle('hidden', unreadCount === 0);
  }
  
  // Update list
  if (notifications.length === 0) {
    notifList.innerHTML = `
      <li class="empty-notifications">
        <p>No notifications yet</p>
      </li>
    `;
    return;
  }

    notifList.innerHTML = notifications.map(notification => `    <li class="notification-item ${notification.read ? 'read' : 'unread'}">      <div class="notification-content" onclick="showNotificationDetails(${notification.id})">        <div class="notification-title">${notification.title}</div>        <div class="notification-meta">${formatRelativeTime(notification.date)}</div>      </div>      ${!notification.read ? `<button class="mark-as-read-btn" onclick="event.stopPropagation(); markAsRead(${notification.id});">Mark as read</button>` : ''}      ${!notification.read ? '<span class="unread-dot"></span>' : ''}    </li>  `).join('');
}

// Toggle notifications panel
function toggleNotifications() {
  const panel = document.getElementById('notifPanel');
  if (!panel) {
    console.error('Notification panel element not found');
    return;
  }
  
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) {
    updateNotificationsUI();
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {  // Add styles for the close button  const style = document.createElement('style');  style.textContent = `    .mark-as-read-btn {      position: absolute;      right: 10px;      top: 50%;      transform: translateY(-50%);      background: none;      border: 1px solid #CC0000;      color: #CC0000;      font-size: 12px;      cursor: pointer;      padding: 4px 8px;      border-radius: 4px;      opacity: 0;      transition: opacity 0.2s, background-color 0.2s;    }    .notification-item:hover .mark-as-read-btn {      opacity: 1;    }    .mark-as-read-btn:hover {      background-color: #CC0000;      color: white;    }    .notification-item {      position: relative;      padding-right: 40px;    }    .button-group {      display: flex;      gap: 10px;      justify-content: flex-end;    }    .modal-actions {      margin-top: 20px;      padding-top: 15px;      border-top: 1px solid #eee;    }  `;  document.head.appendChild(style);  // Initialize notifications from localStorage or use default dummy data
  if (!localStorage.getItem('notifications')) {
    // Set initial dummy notifications
    notifications = [
      {
        id: Date.now() - 1000,
        title: "Company Registration Accepted",
        details: `Your company registration for TechCorp Solutions has been approved by SCAD.

You now have full access to:
- Post internship opportunities
- Review student applications
- Manage interns
- Generate reports

Welcome to the GUC Internship Portal!`,
        date: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
        type: "registration_accepted",
        read: false
      },
      {
        id: Date.now() - 2000,
        title: "New Internship Application",
        details: `A new application has been received:
    
Position: Software Engineering Intern
Applicant: Ahmed Hassan
Student ID: 231047
Major: Computer Science & Engineering
GPA: 3.8

The applicant's resume and portfolio are available for review.`,
        date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        type: "new_application",
        read: true,
        link: "../company/applications.html"
      },
      {
        id: Date.now() - 3000,
        title: "Company Registration Rejected",
        details: `Your company registration for DataTech Inc. has been rejected by SCAD.

Reason: Insufficient company documentation provided.

Please submit a new registration with:
- Valid commercial registration
- Updated company profile
- Complete contact information`,
        date: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
        type: "registration_rejected",
        read: false
      }
    ];
    saveNotifications();
  }
  
  updateNotificationsUI();
});

// Export functions for use in other files
window.addNotification = addNotification;
window.toggleNotifications = toggleNotifications;
window.showNotificationDetails = showNotificationDetails;
window.closeNotificationModal = closeNotificationModal; 