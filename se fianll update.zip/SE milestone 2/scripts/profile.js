// Profile Picture Handling
document.getElementById('profilePictureUpload').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profilePicture').src = e.target.result;
            // Save to localStorage
            localStorage.setItem('profilePicture', e.target.result);
        };
        reader.readAsDataURL(file);
    }
});

// Load saved profile picture on page load
window.addEventListener('load', function() {
    const savedProfilePicture = localStorage.getItem('profilePicture');
    if (savedProfilePicture) {
        document.getElementById('profilePicture').src = savedProfilePicture;
    }
});

// Form Toggle Function with form population
function toggleEdit(formId) {
    const form = document.getElementById(formId);
    const content = form.previousElementSibling;
    
    if (form.classList.contains('hidden')) {
        // Populate form with current values when showing
        if (formId === 'major-form') {
            document.getElementById('name').value = document.getElementById('currentName').textContent;
            document.getElementById('email').value = document.getElementById('currentEmail').textContent;
            document.getElementById('major').value = document.getElementById('currentMajor').textContent.toLowerCase().replace(/\s+/g, '');
            document.getElementById('semester').value = document.getElementById('currentSemester').textContent;
            document.getElementById('gpa').value = document.getElementById('currentGPA').textContent;
        }
    }
    
    form.classList.toggle('hidden');
    content.classList.toggle('hidden');
}

// Dummy data
const dummyData = {
    name: 'John Doe',
    email: 'john.doe@student.guc.edu.eg',
    major: 'Computer Science',
    semester: 8,
    gpa: 3.7,
    experiences: [
        {
            id: 1,
            title: 'Software Engineering Intern',
            company: 'Microsoft',
            duration: 'June 2023 - August 2023',
            responsibilities: 'Developed and maintained cloud-based applications using Azure. Collaborated with senior developers on implementing new features. Participated in daily stand-ups and code reviews.'
        },
        {
            id: 2,
            title: 'Web Development Intern',
            company: 'Amazon',
            duration: 'January 2023 - March 2023',
            responsibilities: 'Built responsive web applications using React and Node.js. Implemented user authentication and authorization. Optimized database queries for better performance.'
        },
        {
            id: 3,
            title: 'Junior Developer',
            company: 'Local Tech Startup',
            duration: 'September 2022 - December 2022',
            responsibilities: 'Developed mobile-first websites for clients. Created and maintained WordPress plugins. Implemented SEO best practices and analytics tracking.'
        }
    ],
    activities: [
        {
            id: 1,
            name: 'GUC Computer Science Society',
            role: 'President',
            duration: 'Fall 2023',
            description: 'Led a team of 10 board members. Organized weekly technical workshops and coding competitions. Managed society budget and partnerships with tech companies.'
        },
        {
            id: 2,
            name: 'Robotics Club',
            role: 'Technical Lead',
            duration: 'Spring 2023',
            description: 'Mentored junior team members in programming robots. Participated in national robotics competition. Conducted workshops on Arduino and Raspberry Pi.'
        },
        {
            id: 3,
            name: 'Competitive Programming Team',
            role: 'Team Member',
            duration: '2022 - 2023',
            description: 'Participated in ACM-ICPC regional contests. Solved complex algorithmic problems. Conducted training sessions for new team members.'
        }
    ]
};

// Initialize with dummy data if no data exists
window.addEventListener('load', function() {
    // Load major information
    if (!localStorage.getItem('currentName')) {
        localStorage.setItem('currentName', dummyData.name);
        localStorage.setItem('currentEmail', dummyData.email);
        localStorage.setItem('currentMajor', dummyData.major);
        localStorage.setItem('currentSemester', dummyData.semester);
        localStorage.setItem('currentGPA', dummyData.gpa);
    }
    
    // Update display with saved data
    document.getElementById('currentName').textContent = localStorage.getItem('currentName');
    document.getElementById('currentEmail').textContent = localStorage.getItem('currentEmail');
    document.getElementById('currentMajor').textContent = localStorage.getItem('currentMajor');
    document.getElementById('currentSemester').textContent = localStorage.getItem('currentSemester');
    document.getElementById('currentGPA').textContent = parseFloat(localStorage.getItem('currentGPA')).toFixed(1);

    // Load experiences and activities
    loadExperiences();
    loadActivities();

    // Load profile picture
    const savedProfilePicture = localStorage.getItem('profilePicture');
    if (savedProfilePicture) {
        document.getElementById('profilePicture').src = savedProfilePicture;
    }
});

// Form submission handlers with validation
document.getElementById('major-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const majorSelect = document.getElementById('major');
    const major = majorSelect.options[majorSelect.selectedIndex].text;
    const semester = parseInt(document.getElementById('semester').value);
    const gpa = parseFloat(document.getElementById('gpa').value);
    
    // Validate inputs
    if (!name) {
        alert('Please enter your name');
        return;
    }
    
    if (!email.endsWith('@student.guc.edu.eg')) {
        alert('Please use your GUC student email');
        return;
    }
    
    if (semester < 1 || semester > 10) {
        alert('Semester must be between 1 and 10');
        return;
    }
    
    if (gpa < 0.7 || gpa > 5.0) {
        alert('GPA must be between 0.7 and 5.0');
        return;
    }
    
    // Update display
    document.getElementById('currentName').textContent = name;
    document.getElementById('currentEmail').textContent = email;
    document.getElementById('currentMajor').textContent = major;
    document.getElementById('currentSemester').textContent = semester;
    document.getElementById('currentGPA').textContent = gpa.toFixed(1);
    
    // Save to localStorage
    localStorage.setItem('currentName', name);
    localStorage.setItem('currentEmail', email);
    localStorage.setItem('currentMajor', major);
    localStorage.setItem('currentSemester', semester);
    localStorage.setItem('currentGPA', gpa);
    
    // Reset form and hide
    this.reset();
    toggleEdit('major-form');
});

// Update the form input for GPA validation
document.getElementById('gpa').addEventListener('input', function() {
    let value = parseFloat(this.value);
    if (value > 5.0) {
        this.value = 5.0;
    } else if (value < 0.7 && value !== '') {
        this.value = 0.7;
    }
});

// Handle experience form
document.getElementById('experience-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const experience = {
        title: document.getElementById('jobTitle').value,
        company: document.getElementById('company').value,
        duration: document.getElementById('duration').value,
        responsibilities: document.getElementById('responsibilities').value,
        id: Date.now() // Unique ID for the experience
    };

    // Save to localStorage
    const experiences = JSON.parse(localStorage.getItem('experiences') || '[]');
    experiences.push(experience);
    localStorage.setItem('experiences', JSON.stringify(experiences));

    // Add to display
    addExperienceToDisplay(experience);

    // Reset form and hide
    this.reset();
    toggleEdit('experience-form');
});

// Handle activities form
document.getElementById('activities-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const activity = {
        name: document.getElementById('activityName').value,
        role: document.getElementById('activityRole').value,
        duration: document.getElementById('activityDuration').value,
        description: document.getElementById('activityDescription').value,
        id: Date.now() // Unique ID for the activity
    };

    // Save to localStorage
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    activities.push(activity);
    localStorage.setItem('activities', JSON.stringify(activities));

    // Add to display
    addActivityToDisplay(activity);

    // Reset form and hide
    this.reset();
    toggleEdit('activities-form');
});

// Load experiences from localStorage
function loadExperiences() {
    const experiences = JSON.parse(localStorage.getItem('experiences') || '[]');
    const container = document.getElementById('experience-list');
    container.innerHTML = ''; // Clear existing content
    experiences.forEach(addExperienceToDisplay);
}

// Add experience to display
function addExperienceToDisplay(experience) {
    const container = document.getElementById('experience-list');
    const div = document.createElement('div');
    div.className = 'experience-item';
    div.innerHTML = `
        <h3>${experience.title}</h3>
        <h4>${experience.company}</h4>
        <p class="experience-meta">${experience.duration}</p>
        <p class="experience-description">${experience.responsibilities}</p>
        <button onclick="deleteExperience(${experience.id})" class="delete-btn">
            Delete
        </button>
    `;
    container.appendChild(div);
}

// Load activities from localStorage
function loadActivities() {
    const activities = JSON.parse(localStorage.getItem('activities') || '[]');
    const container = document.getElementById('activities-list');
    container.innerHTML = ''; // Clear existing content
    activities.forEach(addActivityToDisplay);
}

// Add activity to display
function addActivityToDisplay(activity) {
    const container = document.getElementById('activities-list');
    const div = document.createElement('div');
    div.className = 'activity-item';
    div.innerHTML = `
        <h3>${activity.name}</h3>
        <h4>${activity.role}</h4>
        <p class="activity-meta">${activity.duration}</p>
        <p class="activity-description">${activity.description}</p>
        <button onclick="deleteActivity(${activity.id})" class="delete-btn">
            Delete
        </button>
    `;
    container.appendChild(div);
}

// Delete experience
function deleteExperience(id) {
    if (confirm('Are you sure you want to delete this experience?')) {
        const experiences = JSON.parse(localStorage.getItem('experiences') || '[]');
        const updatedExperiences = experiences.filter(exp => exp.id !== id);
        localStorage.setItem('experiences', JSON.stringify(updatedExperiences));
        loadExperiences(); // Reload the display
    }
}

// Delete activity
function deleteActivity(id) {
    if (confirm('Are you sure you want to delete this activity?')) {
        const activities = JSON.parse(localStorage.getItem('activities') || '[]');
        const updatedActivities = activities.filter(act => act.id !== id);
        localStorage.setItem('activities', JSON.stringify(updatedActivities));
        loadActivities(); // Reload the display
    }
} 