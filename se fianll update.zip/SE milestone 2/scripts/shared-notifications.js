// Notification types and their configurations
const NOTIFICATION_TYPES = {
  new_application: {
    icon: '📝',
    color: '#4CAF50'
  },
  application_status: {
    icon: '📋',
    color: '#2196F3'
  },
  internship_update: {
    icon: '🎓',
    color: '#FF9800'
  },
  registration_accepted: {
    icon: '✅',
    color: '#4CAF50'
  },
  registration_rejected: {
    icon: '❌',
    color: '#f44336'
  }
};

// Initial notifications for different pages
const INITIAL_NOTIFICATIONS = {
  applications: [
    {
      id: Date.now() - 1000,
      title: "New Application Received",
      details: `A new application has been received:
      
Position: Frontend Developer Intern
Applicant: Layla Ibrahim
Student ID: 231092
Major: Computer Science & Engineering
GPA: 3.7

The applicant's resume and portfolio are available for review.`,
      date: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      type: "new_application",
      read: false,
      link: "./applications.html"
    },
    {
      id: Date.now() - 2000,
      title: "Application Status Updated",
      details: `The status of your application has been updated:

Position: Software Engineering Intern
Company: TechCorp Solutions
New Status: Under Review

Your application is being reviewed by the hiring team.`,
      date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      type: "application_status",
      read: true,
      link: "./applications.html"
    }
  ],
  internships: [
    {
      id: Date.now() - 1000,
      title: "Internship Position Updated",
      details: `Changes have been made to your internship posting:

Position: Frontend Developer Intern
Updates:
- Required skills updated
- Application deadline extended
- New project details added

Please review the changes in the internship details.`,
      date: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      type: "internship_update",
      read: false,
      link: "./internships.html"
    },
    {
      id: Date.now() - 2000,
      title: "New Applicant Shortlisted",
      details: `A candidate has been shortlisted for your internship position:

Position: Software Engineering Intern
Candidate: Ahmed Hassan
Status: Ready for Interview

Please review the candidate's profile and schedule an interview.`,
      date: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
      type: "new_application",
      read: true,
      link: "./applications.html"
    }
  ]
};

// Format relative time
function formatRelativeTime(dateString) {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);
    
    if (isNaN(diffInSeconds)) return 'Just now';
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) {
      const mins = Math.floor(diffInSeconds / 60);
      return `${mins}m ago`;
    }
    if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours}h ago`;
    }
    if (diffInSeconds < 604800) {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days}d ago`;
    }
    
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  } catch (e) {
    console.error('Date formatting error:', e);
    return 'Recent';
  }
}

// Initialize notifications for a specific page
function initializeNotifications(page) {
  const storageKey = `notifications_${page}`;
  let notifications = JSON.parse(localStorage.getItem(storageKey));
  
  if (!notifications) {
    notifications = INITIAL_NOTIFICATIONS[page] || [];
    localStorage.setItem(storageKey, JSON.stringify(notifications));
  }
  
  return notifications;
}

// Add new notification
function addNotification(page, notification) {
  const storageKey = `notifications_${page}`;
  const notifications = initializeNotifications(page);
  
  const newNotification = {
    id: Date.now(),
    date: new Date().toISOString(),
    read: false,
    ...notification
  };

  notifications.unshift(newNotification);
  localStorage.setItem(storageKey, JSON.stringify(notifications));
  updateNotificationsUI(page);
}

// Mark notification as read
function markAsRead(page, id) {
  const storageKey = `notifications_${page}`;
  const notifications = initializeNotifications(page);
  
  const notification = notifications.find(n => n.id === id);
  if (notification) {
    notification.read = true;
    localStorage.setItem(storageKey, JSON.stringify(notifications));
    updateNotificationsUI(page);
  }
}

// Get unread count
function getUnreadCount(page) {
  const notifications = initializeNotifications(page);
  return notifications.filter(n => !n.read).length;
}

// Show notification details modal
function showNotificationDetails(page, id) {
  const notifications = initializeNotifications(page);
  const notification = notifications.find(n => n.id === id);
  if (!notification) return;

  markAsRead(page, id);

  const modal = document.createElement('div');
  modal.className = 'modal notification-modal';
  modal.innerHTML = `
    <div class="modal-content">
      <div class="notification-header">
        <h3>${notification.title}</h3>
        <span class="notification-date">${formatRelativeTime(notification.date)}</span>
      </div>
      <div class="notification-body">
        <p>${notification.details}</p>
      </div>
      <div class="modal-actions">
        ${notification.link ? 
          `<div class="button-group">
            <button class="btn-primary" onclick="window.location.href='${notification.link}'">View Details</button>
            <button class="btn-secondary" onclick="closeNotificationModal()">Close</button>
          </div>` 
          : '<button class="btn-secondary" onclick="closeNotificationModal()">Close</button>'}
      </div>
    </div>
  `;
  
  const container = document.getElementById('notificationModalContainer') || document.body;
  container.appendChild(modal);
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.querySelector('.notification-modal');
  if (modal) {
    modal.remove();
  }
}

// Update notifications UI
function updateNotificationsUI(page) {
  const notifications = initializeNotifications(page);
  const notifCount = document.getElementById('notifCount');
  const notifList = document.getElementById('notifList');
  const unreadCount = getUnreadCount(page);
  
  if (!notifList) {
    console.error('Notification list element not found');
    return;
  }

  // Update badge
  if (notifCount) {
    notifCount.textContent = unreadCount;
    notifCount.classList.toggle('hidden', unreadCount === 0);
  }
  
  // Update list
  if (notifications.length === 0) {
    notifList.innerHTML = `
      <li class="empty-notifications">
        <p>No notifications yet</p>
      </li>
    `;
    return;
  }

  notifList.innerHTML = notifications.map(notification => `
    <li class="notification-item ${notification.read ? 'read' : 'unread'}">
      <div class="notification-content" onclick="showNotificationDetails('${page}', ${notification.id})">
        <div class="notification-title">${notification.title}</div>
        <div class="notification-meta">${formatRelativeTime(notification.date)}</div>
      </div>
      ${!notification.read ? 
        `<button class="mark-as-read-btn" onclick="event.stopPropagation(); markAsRead('${page}', ${notification.id});">Mark as read</button>` 
        : ''}
      ${!notification.read ? '<span class="unread-dot"></span>' : ''}
    </li>
  `).join('');
}

// Toggle notifications panel
function toggleNotifications(page) {
  const panel = document.getElementById('notifPanel');
  if (!panel) {
    console.error('Notification panel element not found');
    return;
  }
  
  panel.classList.toggle('hidden');
  if (!panel.classList.contains('hidden')) {
    updateNotificationsUI(page);
  }
}

// Add styles
document.addEventListener('DOMContentLoaded', () => {
  const style = document.createElement('style');
  style.textContent = `
    .notification-wrapper {
      position: relative;
      margin-right: 20px;
    }

    .notification-button {
      position: relative;
      display: inline-flex;
      align-items: center;
      padding: 8px 16px;
      background: none;
      border: none;
      cursor: pointer;
      color: #333;
      font-size: 14px;
      gap: 8px;
      border-radius: 4px;
      transition: background-color 0.2s;
    }

    .notification-button:hover {
      background-color: rgba(204, 0, 0, 0.1);
    }

    .notification-button i {
      font-size: 18px;
      color: #CC0000;
    }

    .notif-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background-color: #CC0000;
      color: white;
      border-radius: 50%;
      padding: 2px 6px;
      font-size: 12px;
      min-width: 15px;
      text-align: center;
    }

    .notif-panel {
      position: absolute;
      top: 100%;
      right: 0;
      width: 350px;
      max-height: 400px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 1000;
      overflow: hidden;
      margin-top: 8px;
    }

    .notif-panel h4 {
      margin: 0;
      padding: 16px;
      border-bottom: 1px solid #eee;
      color: #333;
      font-size: 16px;
    }

    .notif-panel ul {
      margin: 0;
      padding: 0;
      list-style: none;
      max-height: 350px;
      overflow-y: auto;
    }

    .notification-item {
      padding: 12px 16px;
      border-bottom: 1px solid #eee;
      position: relative;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .notification-item:hover {
      background-color: #f8f8f8;
    }

    .notification-item.unread {
      background-color: #fff5f5;
    }

    .notification-item.unread:hover {
      background-color: #ffe5e5;
    }

    .notification-title {
      font-weight: 600;
      color: #333;
      margin-bottom: 4px;
      padding-right: 80px;
    }

    .notification-meta {
      font-size: 12px;
      color: #666;
    }

    .mark-as-read-btn {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: 1px solid #CC0000;
      color: #CC0000;
      font-size: 12px;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 4px;
      opacity: 0;
      transition: all 0.2s;
    }

    .notification-item:hover .mark-as-read-btn {
      opacity: 1;
    }

    .mark-as-read-btn:hover {
      background-color: #CC0000;
      color: white;
    }

    .unread-dot {
      position: absolute;
      top: 50%;
      right: 8px;
      transform: translateY(-50%);
      width: 8px;
      height: 8px;
      background-color: #CC0000;
      border-radius: 50%;
    }

    .empty-notifications {
      padding: 20px;
      text-align: center;
      color: #666;
    }

    .notification-modal {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1001;
    }

    .notification-modal .modal-content {
      background: white;
      border-radius: 8px;
      width: 90%;
      max-width: 500px;
      padding: 24px;
      position: relative;
    }

    .notification-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 16px;
    }

    .notification-header h3 {
      margin: 0;
      color: #333;
    }

    .notification-date {
      color: #666;
      font-size: 14px;
    }

    .notification-body {
      margin-bottom: 20px;
      white-space: pre-line;
      color: #444;
      line-height: 1.5;
    }

    .modal-actions {
      border-top: 1px solid #eee;
      padding-top: 16px;
      margin-top: 16px;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    .btn-primary {
      background-color: #CC0000;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-primary:hover {
      background-color: #990000;
    }

    .btn-secondary {
      background-color: #f0f0f0;
      color: #333;
      border: none;
      padding: 8px 16px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-secondary:hover {
      background-color: #e0e0e0;
    }

    /* Custom scrollbar for notifications panel */
    .notif-panel ul::-webkit-scrollbar {
      width: 6px;
    }

    .notif-panel ul::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    .notif-panel ul::-webkit-scrollbar-thumb {
      background: #CC0000;
      border-radius: 3px;
    }

    .notif-panel ul::-webkit-scrollbar-thumb:hover {
      background: #990000;
    }

    .hidden {
      display: none !important;
    }
  `;
  document.head.appendChild(style);
});

// Export functions
window.addNotification = addNotification;
window.toggleNotifications = toggleNotifications;
window.showNotificationDetails = showNotificationDetails;
window.closeNotificationModal = closeNotificationModal;
window.markAsRead = markAsRead; 