// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize notifications
    updateNotificationsUI('dashboard');

    // Add event listeners to register buttons
    const registerButtons = document.querySelectorAll('.btn-register');
    registerButtons.forEach(button => {
        button.addEventListener('click', handleEventRegistration);
    });
});

// Handle event registration
function handleEventRegistration(event) {
    const eventCard = event.target.closest('.event-card');
    const eventTitle = eventCard.querySelector('h3').textContent;
    const eventDate = eventCard.querySelector('.event-date').textContent;
    
    // Add registration to localStorage
    const registrations = JSON.parse(localStorage.getItem('eventRegistrations') || '[]');
    registrations.push({
        title: eventTitle,
        date: eventDate,
        registeredAt: new Date().toISOString()
    });
    localStorage.setItem('eventRegistrations', JSON.stringify(registrations));

    // Update UI
    event.target.textContent = 'Registered';
    event.target.disabled = true;
    event.target.classList.add('registered');

    // Add notification
    addNotification({
        title: 'Event Registration Successful',
        details: `You have been registered for ${eventTitle} on ${eventDate}`,
        type: 'event_registration',
        link: '#'
    });
}

// Navigation function
function navigateToPage(page) {
    switch(page) {
        case 'dashboard':
            window.location.href = 'pro-dashboard.html';
            break;
        case 'internships':
            window.location.href = 'premium-internships.html';
            break;
        case 'applications':
            window.location.href = 'applications.html';
            break;
        case 'progress':
            window.location.href = 'progress.html';
            break;
        case 'schedule':
            window.location.href = 'schedule.html';
            break;
        case 'profile':
            window.location.href = 'enhanced-profile.html';
            break;
        case 'workshops':
            window.location.href = 'pro-workshops.html';
            break;
        default:
            console.error('Unknown page:', page);
    }
}

// Mock analytics data update (in real app, this would come from an API)
setInterval(() => {
    const profileViews = document.querySelector('.stat-card:nth-child(1) .stat-number');
    const successRate = document.querySelector('.stat-card:nth-child(2) .stat-number');
    
    // Randomly update profile views
    const currentViews = parseInt(profileViews.textContent);
    const newViews = currentViews + Math.floor(Math.random() * 5);
    profileViews.textContent = newViews;

    // Randomly update success rate
    const currentRate = parseInt(successRate.textContent);
    const newRate = Math.min(100, currentRate + Math.floor(Math.random() * 3));
    successRate.textContent = `${newRate}%`;
}, 30000); // Update every 30 seconds 